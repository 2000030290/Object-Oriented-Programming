package accountinfo;
import java.util.Scanner;
public class BankCustom {

	public static void main(String[] args) {
	    Customerinfo a=new Customerinfo(1245,1000.0);
		Scanner sc=new Scanner(System.in);
		System.out.println(a);
		System.out.println("Enter amount to withdraw");
		a.withdraw(sc.nextDouble());
		System.out.println(a);
		System.out.println("Enter amount to deposit");
		a.deposit(sc.nextDouble());
		System.out.println(a);
		sc.close();

	}

}
