package accountinfo;

public class Customerinfo {
	private int id;
	private double balance;
	public Customerinfo()
	{
	this.id=0;
	this.balance=0;
	}
	public Customerinfo(int id, double balance)
	{
	this.id = id;
	this.balance = balance;
	}
	public int getId()
	{
	return id;
	}
	public boolean setId(int id)
	{
	if(id>0)
	{
	this.id = id;
	return true;
	}
	else
	{
	this.id=0;
	return false;
	}
	}
	public double getBalance()
	{
	return balance;
	}
	public boolean setBalance(double balance)
	{
	if(balance>0)
	{
	this.balance=balance;
	return true;
	}
	else
	return false;
	}
	public String toString()
	{
	String s;
	s="Account Num:"+id+"\nBalance:"+balance;
	return s;
	}
	public void withdraw(double amt)
	{
	if(amt<=this.balance)
	{
	System.out.println("Withdraw Succesfull");
	this.balance-=amt;
	}
	else
	System.out.println("Insufficient balance");
	}
	public void deposit(double amt)
	{
	if(amt>0)
	{
	System.out.println("Deposit successfull");
	this.balance+=amt;
	}
	else
	System.out.println("Invalid Amount");
	}
	}


