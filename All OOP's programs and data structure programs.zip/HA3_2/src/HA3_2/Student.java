package HA3_2;

public class Student {
	private long id;
	private String name;
	 private long Mobile;

	public Student(long id,String name, long Mobile) throws InvalidIDException, InvalidNameException, InvalidMobileException
	{
		setId(id);
		setName(name);
		setMobile(Mobile);
		
	}
	 public void setId(long id) throws InvalidIDException
	  { 
	    if(id>=1000000000 && id<= 9999999999l)
	    {
	    	this.id=id;
	    }
	    else
	    {
	      throw new InvalidIDException();
	    }
	      
	      
	  }
	 public void setName(String name) throws InvalidNameException {
		
		for(int i=0;i<name.length();i++) {
			 if((name.charAt(i)>='A' && name.charAt(i) <= 'Z' ) || (name.charAt(i)>='a' && name.charAt(i) <= 'z' ))
			  { 
	              this.name=name;
	            }
	           
	          else
	          {
	            throw new InvalidNameException();
	          }
		}
	            
	        } 
	    public void setMobile(long Mobile) throws InvalidMobileException 
	      { 
	        if(Mobile>=1000000000 && Mobile<= 9999999999l)
	        {
	          this.Mobile=Mobile;
	        }
	        else
	        {
	          throw new InvalidMobileException();
	        }
	      }
	 public String toString()
		{
			String s;
			s="\n ID-"+id;
			s=s+"\n Name-"+name;
			s=s+"\n Mobile number-"+Mobile;
			return s;
		}

}
