package HA3_2;

public class InvalidMobileException extends Exception{
	public String toString()
	  {
	    return "Invalid Mobile Exception";
	  }

}
