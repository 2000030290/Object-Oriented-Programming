package HA3_2;

public class InvalidNameException extends Exception {
	public String toString()
	{
		
		return "Invalid Name ";
	}

}
