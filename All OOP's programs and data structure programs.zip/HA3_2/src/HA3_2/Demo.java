package HA3_2;
import java.util.Scanner;
public class Demo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try
		{
			
			Student s=new Student(sc.nextLong(),sc.next(),sc.nextLong());
			System.out.println(s);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}

	}

}
