package HA3_2;

public class InvalidIDException extends Exception {
	
	public String toString()
	{
		
		return "Invalid Value of ID ";
	}

}
