package Binarysearch;

import java.util.Scanner;

public class BinarySearch {
	static Scanner sc=new Scanner(System.in);
	static int size;
	static int a[];

	public static void main(String[] args) {
		System.out.println("Enter size of array");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("Enter the array elements");
		for(int i=0;i<size;i++)
		a[i]=sc.nextInt();
		System.out.println("Enter the key");
		int key=sc.nextInt();
		int f=binarySearch(key);
		if(f==-1)
			System.out.println("Element is not found");
		else
			System.out.println(key+"is found at"+f+"position");
		

	}

	private static int binarySearch(int key) {
		int low=0,high =size-1;
		int mid;
		mid=(low+high)/2;
		if(a[mid]==key)
	    return mid;
		else if(key<a[mid])
			high=mid-1;
		else 
			low=mid+1;
	
		return -1;
}

}
