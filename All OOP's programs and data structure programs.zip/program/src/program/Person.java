package program;

public class Person {
	String name,address,email;
	long number;
	public void setDetials(String nm,String e,String a,long n)
	{
	name = nm;
	address = a;
	email = e;
	number = n;
	}
}
