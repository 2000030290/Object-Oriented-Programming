package program;
import java .util.Scanner;
public class EightTwo {

	public static void main(String[] args) {
		  Student1 s1 = new Student1();
		    Faculty f1 = new Faculty();
		    Staff s2 = new Staff();
		    Scanner s = new Scanner(System.in);
		    String name,email,address,designation,dateHired;
		    double cgpa,hoursWorked,salary;
		    long number;
		    name = s.nextLine();
		    email = s.nextLine();
		    address = s.nextLine();
		    number = s.nextLong();
		    cgpa = s.nextDouble();
		    s1.SetDetials(name, email, address, number);
		    s1.SetCGPA(cgpa);
		    s.nextLine();
		    name = s.nextLine();
		    email = s.nextLine();
		    address = s.nextLine();
		    number = s.nextLong();
		    s.nextLine();
		    designation = s.nextLine();
		    dateHired = s.nextLine();
		    salary = s.nextDouble();
		    f1.setDetials(name, email, address, number);
		    f1.setDes(designation);
		    f1.setValues(salary, dateHired);
		    s.nextLine();
		    name = s.nextLine();
		    email = s.nextLine();
		    address = s.nextLine();
		    number = s.nextLong();
		    hoursWorked = s.nextDouble();
		    s2.setDetials(name, email, address, number);
		    s2.setHW(hoursWorked);
		    s2.setValues(salary, dateHired);
		    System.out.println(s1.printDetail());
		    System.out.println(f1.printDetail());
		    System.out.println(s2.printDetail());
		    s.close();
		    }
	

	}


