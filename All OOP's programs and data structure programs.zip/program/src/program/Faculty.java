package program;

public class Faculty {

}
