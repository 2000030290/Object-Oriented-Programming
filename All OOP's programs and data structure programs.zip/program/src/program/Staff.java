package program;

public class Staff  extends Employee1{
	  double hoursWorked;
	  public void setHW(double hw)
	  {
	  hoursWorked = hw;
	  }
	  public double getHoursWorked()
	  {
	  return hoursWorked;
	  }
	  public String printDetail()
	  {
	  return "PersonDetails:\nName:"+name+"\tAddress:"+address+"\tEmail:"+email+"\tNumber:"+number+"\tSalary:"+salary+"\tDateHired:"+dateHired+"\tHoursWorked:"+hoursWorked;
	  }

}
