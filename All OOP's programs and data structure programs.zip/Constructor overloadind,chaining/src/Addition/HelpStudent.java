package Addition;

import java.util.*;
public class HelpStudent {
    HelpStudent(double a,double b) {
        System.out.println("addition of "+a+","+b+" is " +(a+b));
    }
    HelpStudent(double a,double b,double c){
        this(a,b);
        System.out.println("addition of "+a+","+b+","+c+" is " +(a+b+c));
    }
    HelpStudent(double a,double b,double c,double d){
        this(a,b,c);
        System.out.println("addition of "+a+","+b+","+c+","+d+" is "+(a+b+c+d));
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("***ADDITION MENU***\n1.Two numbers\n2.Three numbers\n3.Four numbers\n4.exit");
        System.out.println("Enter you choice:");
        int x=sc.nextInt();
        switch(x) {
        case 1:
            System.out.println("Enter two numbers for addition");
            double a=sc.nextDouble();
            double b=sc.nextDouble();
            HelpStudent n=new HelpStudent(a,b);
            break;
        case 2:
            System.out.println("Enter three numbers for addition");
            double c=sc.nextDouble();
            double d=sc.nextDouble();
            double e=sc.nextDouble();
            HelpStudent n1=new HelpStudent(c,d,e);
            break;
        case 3:
            System.out.println("Enter four numbers for addition");
            double f=sc.nextDouble();
            double g=sc.nextDouble();
            double h=sc.nextDouble();
            double i=sc.nextDouble();
            HelpStudent n2=new HelpStudent(f,g,h,i);
            break;
        case 4:
            break;
        default:
            System.out.println("CAUTION: please enter a valid input");
        }

    }
 
}