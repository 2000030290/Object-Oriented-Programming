package sample1;

public class Demo {

	public static void main(String[] args) {
		Cuboid c=new Cuboid(1,2,3);
		System.out.println(c.area());
		Rectangle r=new Rectangle(1,2);
		System.out.println(r.area());

	}

}
