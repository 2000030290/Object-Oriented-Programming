package sample1;

public class Cuboid extends Rectangle {
     
	private double height;
      public Cuboid (double length,double breadth,double height)
      {
    	  super(length,breadth);
    	  this.height=height;
      }
     
      public double area()
      {
    	  return 2*(getLength()*getBreadth()+getBreadth()*height+height*getLength());
      }
      
}
