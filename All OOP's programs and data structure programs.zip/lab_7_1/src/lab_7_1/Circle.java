package lab_7_1;

public class Circle extends Shape {
	private double radius;
	public String toString()
	{
		String s1;
		s1="Radius is-"+radius+"\nFillColor-"+fillColor+"\nBorderColor is-"+borderColor
				+"\nFill-"+fill+"\nBorderWidth-"+borderWidth;
		return s1;
	}
	public void setRadius(double radius) 
	{
		this.radius=radius;
	}
	public double getRadius()
	{ 
		return radius;
	}
}
