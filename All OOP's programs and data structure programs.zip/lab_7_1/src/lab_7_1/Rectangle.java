package lab_7_1;

public class Rectangle extends Shape{
	private double length,breadth;
	public void setLength(double l) {
		this.length=l;
	}
	public void setBreadth(double b) {
		this.breadth=b;
	}
	public String toString() {
		String s;
		s="Length is-"+length+"\nBreadth is-"+breadth+"\nBorderWidth-"+borderWidth
				+"\nBorderColor is-"+borderColor+"\nFill-"+fill+"\nFillColor-"+fillColor;
		return s;
	}
}
