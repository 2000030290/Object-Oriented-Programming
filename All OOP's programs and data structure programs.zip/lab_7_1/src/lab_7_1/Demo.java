package lab_7_1;

public class Demo {

	public static void main(String[] args) {
		Rectangle r=new Rectangle();
		r.setLength(45);
		r.setBreadth(50);
		r.fillColor="GREEN";
		r.borderColor="RED";
		r.fill=true;
		r.borderWidth=10;
		System.out.println(r);
		
		Circle c=new Circle();
		c.setRadius(5);
		c.fillColor="GREY";
		c.borderColor="BLUE";
		c.fill=true;
		c.borderWidth=20;
		System.out.println("\n"+c);


	}

}
