package lab_7_1;

public class Shape {
	public double borderWidth;
	public String borderColor,fillColor;
	public boolean fill;

}
