package stack;

import java.util.Scanner;

public class Demo {
    static Scanner sc=new Scanner(System.in);
    static Mystack m= new Mystack(10);

	public static void main(String[] args) {
		boolean repeat=true;
		int choice;
		while (repeat)
		{
			System.out.println("***MENU***");
			System.out.println("1.PUSH");
			System.out.println("2.POP");
			System.out.println("3.PEEK");
			System.out.println("4.DISPLAY");
			System.out.println("5.EXIT");
			choice=sc.nextInt();
			switch(choice)
			{
				case 1:
					System.out.println("Enter element to be pushed");
					m.push(sc.nextInt());
					break;
				case 2: m.pop();
				break;
				case 3:
					m.peek();
					break;
				case 4:
					m.display();
					break;
				case 5:
					repeat=false;
					break;
			}
			
		}
		

	}

	

}
