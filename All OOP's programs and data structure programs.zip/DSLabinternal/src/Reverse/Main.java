package Reverse;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	
		  Scanner sc=new Scanner(System.in);
	      SLL qq=new SLL();
	    while(true)
	    {
	    System.out.println("*** Menu ***");
	    System.out.println("1.Creat");
	    System.out.println("2.Insert");
	    System.out.println("6.Exit");
	    System.out.println("Enter your choice");
	    int cho=sc.nextInt();
	    switch(cho)
	    {
	    case 1: 
	      qq.create();
	      break;
	    case 2:
	    	qq.display();
	    	break;

	}
	    }
}
}
