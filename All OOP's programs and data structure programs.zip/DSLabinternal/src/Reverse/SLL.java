package Reverse;

import java.util.Scanner;

public class SLL {
	Node<Integer> start = null; 
    public void create() 
    { 
      char choice; 
      int d; 
      Scanner sc=new Scanner(System.in); 
      Node<Integer> latest=null; 
      do {  
        System.out.println("enter the data");
        d=sc.nextInt(); 
        Node<Integer> n=new Node<Integer> (d); 
        if(start==null) 
        { 
          start=n; 
          latest=n;
        } 
        else  
        { 
          latest.next=n; 
          latest=n;
        } 
        System.out.println("do you want to continuosly? Y or No"); 
        choice=sc.next().charAt(0); 
      } 
      while(choice=='Y' || choice=='y');        
      }

    public void display()
    {
     Node<Integer>t=start;
     while(t!=null)
     {
      System.out.println(t.data);
      t=t.next;
     }
    }
}