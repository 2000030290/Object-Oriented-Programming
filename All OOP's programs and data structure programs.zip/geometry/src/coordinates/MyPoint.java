package coordinates;

public class MyPoint {
	private double x;
	private double y;
	public MyPoint()
	{
	this.x=this.y=0;
	}
	public MyPoint(double x,double y)
	{
	this.x=x;
	this.y=y;
	}
	public double distance(double x,double y)
	{
	double a=Math.pow(this.x-x,2);
	double b=Math.pow(this.y-y,2);
	return Math.sqrt(a+b);
	}
	public double distance(MyPoint p) //Passing object as argument
	{
	double a=Math.pow(this.x-p.x,2);
	double b=Math.pow(this.y-p.y,2);
	return Math.sqrt(a+b);

}
}
