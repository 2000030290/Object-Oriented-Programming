package Evaluation;

public class postfixEvaluation {

	static String Input=null;
	static Stack<Character> st;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size");
		int size=sc.nextInt();
		st=new Stack<Character>();
		System.out.println("Enter input String");
		Input =sc.next();
		int a,b,c=0;
		st=new Stack<Character>();
		for(int i=0;i<Input.length();i++)
		{
		char ch=Input.charAt(i);
		if(Character.isDigit(ch))
		{
		st.push((char)Character.getNumericValue(ch));
		}
		else
		{
		a=(int)st.pop();
		b=(int)st.pop();
		switch(ch)
		{
		case '+':c=b+a;
		break;
		case '-':c=b-a;
		break;
		case '*':c=b*a;
		break;
		case '/':c=b/a;
		break;
		}
		st.push((char)c);
		}
		}
		System.out.println("the final result:"+(int)st.pop());

	}

}
