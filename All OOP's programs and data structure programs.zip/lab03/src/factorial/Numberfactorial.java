package factorial;

public class Numberfactorial {
	public static int factorial(int n)
	{
	int f=1;
	for(int i=1;i<=n;i++)
	{
	f=f*i;
	}
	return f;
	}
	public static void main(String[] args)
	{
	int a=Integer.parseInt(args[0]);
	System.out.println(factorial(a));
	}
}
