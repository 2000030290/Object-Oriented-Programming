package lab_6_1;
import java.util.Scanner;
public class EmployeeDemo {

	public static void main(String[] args) {
		Object system;
		  Scanner sc = new Scanner(System.in);
		  
		  Employee e[] =new Employee[10];
		  int count =0;
		  int id;
		  String name,dept;
		  boolean repeat =true;
		  while(repeat)
		  {
		  
		   System.out.println(" create new employee,2.update new name 3. print all employee details 4.print specific department employee details 5.exit");
		  int choice =sc.nextInt();
		  if (choice==1)
		  { 
		   System.out.println("enter employee id,name,department");
		   id=sc.nextInt();
		   name=sc.next();
		   dept=sc.next();
		   e[count]=new Employee();
		   count++;
		  }
		  else if(choice==2)
		  { int no;
		  System.out.println(" enter employee id");
		  no=sc.nextInt();
		  System.out.println("enter new name");
		  String newname;
		  newname=sc.next();
		  for(int i=0;i<count;i++)
		  {
		   if(e[i].getid()==no);
		   {
		    e[i].setname(newname);
		   }
		  }
		  }
		  else if(choice==3)
		  {
		   for(int i=0;i<count;i++)
		   {
		    System.out.println( e[i].toString());
		   }
		  }
		  else if(choice==4)
		  {
		   String d;
		   System.out.println(" enter department name");
		   d=sc.next();
		   for(int i=0;i<count;i++)
		   {
		    if(e[i].getdept().equalsIgnoreCase(d))
		    {
		     System.out.println(e[i].toString());
		    } 
		    }
		  }
		  else if(choice==5)
		  {
		   repeat=false;
		  }
		 }
		 
		 
		}

	}


