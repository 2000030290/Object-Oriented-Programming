package lab_6_1;

public class Employee {
	private int id;  
	 private String name;
	 private String dept;
	 Employee ()

	 {
	  id=0;
	  name="H";
	  dept="H";
	 }
	 Employee (int i,String n,String d)
	 {
	  id=i;
	  name=n;
	  dept =d;
	 }
	 public void setid(int i)
	 {
	  id=i;
	 }
	 public void setname( String n)
	 {
	  name=n;
	 }
	 public void setdept( String d)
	 {
	  dept=d;
	 }
	 public int getid()
	 {
	 return id;
	}
	public String getname()
	{
	 return name;
	}
	 public String getdept()
	 {
	  return dept;
	 }
	 public String toString()
	 {
	  String msg;
	  msg=String.format ("id:%d%n name:%s %n department:%s",getid(),getname
	    (),getdept());
	  return msg;
	 }

}
