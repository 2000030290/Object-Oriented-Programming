package InfixtoPostfixConvert;

import java.util.Scanner;

public class InfixToPostfix {

			static String infixEx;
			   static String postfixEx;
			   static Stack s;
			   public static void main(String[] args)
			  {
			   Scanner sc=new Scanner(System.in);
			   System.out.println("Enter input Expression");
			   infixEx=sc.next();
			   postfixEx=new String();
			   s=new Stack(10);
			   convertToPost();
			   System.out.println(postfixEx);
			   }
			   public static void convertToPost() {
			   for(int i=0;i<infixEx.length();i++) {
			   char c=infixEx.charAt(i);
			   if(c=='(') {
			   s.push(c);
			   }
			   else if(Character.isAlphabetic(c))
			  {
			   postfixEx+=c;
			   }
			   else if(c==')') {
			   while(s.top!=-1 && s.peek()!='(')
			  {
			   Object x= s.pop();
			   postfixEx+=x;
			   }
			   s.pop();
			   }
			   else if(c=='+'||c=='-'||c=='*'||c=='/') {
			   while(s.top!=-1 && s.peek()!='('&& getPriority(s.peek())>=getPriority(c))
			   {
			   Object x=s.pop();
			   postfixEx+=x;
			   }
			   s.push(c);
			   }
			   }
			   while(s.top!=-1) {
			   postfixEx+=s.pop();
			   }
			   }
			   public static int getPriority(char ch)
			   {
			    if(ch=='^')
			    return 2;
			    else if(ch=='*'||ch=='/')
			    return 1;
			    else
			    return 0;
			    }
			    }