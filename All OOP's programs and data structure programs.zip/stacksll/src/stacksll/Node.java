package stacksll;

public class Node <T>{
	T data;
	Node <T>next;
	public Node(T data)
	{
		this.data=data;
		next=null;
	}

		Node <T>top=null;
		public void push(T d)
		{
			Node <T> n=new Node(d);
			if(top==null)
			top=n;
			else
			{
				n.next=top;
				top=n;
			}
		}
		public void pop()
		{
			if(top==null)
			{
				System.out.println("Stack is underflown");
			}
			else
			{
				System.out.println(top.data+"is removed");
				top=top.next;
			}
				
		}
		public void peek()
		{
			if(top==null)
			{
				System.out.println("Stack is underflown");
			}
			else
				System.out.println(top.data+"is the peek element");	
		}
		
		public void display()
		{
			Node<T>tmp=top;
			while(tmp!=null)
			{
				System.out.println(tmp.data);
				tmp=tmp.next;
			}
		}
	}

