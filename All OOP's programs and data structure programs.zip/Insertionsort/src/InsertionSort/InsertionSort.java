package InsertionSort;
import java.util.Scanner;
public class InsertionSort {

	public static void main(String[] args) {
 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array");
		int n=sc.nextInt();
		System.out.println("Enter elements into the array");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		insSort(a);
		System.out.println("After sorting");
		for(int i=0;i<n;i++)
		System.out.println(a[i]);
		
	}

	private static void insSort(int a[]) {
		
		int tmp,j;
		for(int i=1;i<a.length;i++)
		{
			tmp=a[i];
			for(j=i-1;j>=0&&tmp<a[j];j--)
			{
				a[j+1]=a[j];
			}
		     
			a[j+1]=tmp;	
		}
	}

}
