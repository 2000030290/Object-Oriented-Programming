package Abstracts;

public interface AbstractClass {
	
	public void changeGear(int a);
    public void speedUp(int a);
	public void applyBrakes(int a);
}
