package Abstracts;

public class Bycycle implements AbstractClass{
     public int speed;
     public int gear;
	
	public void changeGear(int newgear) {
		gear=gear+newgear;
		
	}

	
	public void speedUp(int increment) {
		speed=speed+increment;
		
	}

	
	public void applyBrakes(int decrement) {
		
		gear=gear-decrement;
	}
	public void printStates() {
        System.out.println("speed: " + speed
             + " gear: " + gear);
	}
}
