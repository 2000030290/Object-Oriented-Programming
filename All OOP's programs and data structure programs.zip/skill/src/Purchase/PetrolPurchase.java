package Purchase;

public class PetrolPurchase {
	private String location;
	private String petroltype;
	private int quantity;
	private double literprice;
	private double discount;
	
		public void setlocation(String location)
		{
			this.location=location;
		}
		public void setpetroltype(String petroltype)
		{
			this.petroltype=petroltype;
		}
		public void setquantity(int quantity)
		{
			this.quantity=quantity;
		}
		public void setliterprice(double literprice)
		{
			this.literprice=literprice;
		}
		public void setdiscount(double discount)
		{
			this.discount=discount;
		}
		public String get()
		{
			return location;
		}
		public String getlocation()
		{
			return location;
		}
		public String getlocation()
		{
			return location;
		}
		public String getlocation()
		{
			return location;
		}
		public String getlocation()
		{
			return location;
		}
	
	

}

