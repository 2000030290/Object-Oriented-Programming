package Skilling5;
import java.util.Scanner;

public class TaxCalculator {
 	 
 	public void calculateTax() 
 	{ 
    Scanner sc=new Scanner(System.in);
    boolean repeat = true;  
    while(repeat) 
 	 	{ 
    System.out.println("MENU\n1.Books\n2.CDs\n3.Cosmetics\n4.exit"); 
    System.out.println("Enter your choice");   
    int x=sc.nextInt(); 
    switch(x) 
  	 	{ 
 	case 1: 
    System.out.println("Enter no of books: ");   
    int y=sc.nextInt(); 
    System.out.println("Enter price per each:"); 
    int z=sc.nextInt(); 
    System.out.println("Total fare: "+(y*z)); 
    System.out.println("Books are exempted from sales tax"); 
 	break;  	 	 	
 	case 2: 
    System.out.println("Enter no of CDs: ");  
    int a=sc.nextInt(); 
    System.out.println("Enter price per each: ");   
    float b=sc.nextFloat(); 
    System.out.println("Sales tax: "+ (a*b*0.1));
    System.out.println("Imported tax :"+ (a*b*0.05));      
    System.out.println("Total fare inclusive of taxes: "+ (a*b*1.15)); 
 	break;  	 	
 	case 3: 
 	System.out.println("Enter no of cosmetics: "); 
 	int c=sc.nextInt(); 
    System.out.println("Enter price per each: "); 
    float d=sc.nextFloat(); 
 	System.out.println("Sales tax: "+ (c*d*0.1));
 	System.out.println("Total fare inclusive of taxes: "+ ((c*d)+(c*d*0.1))); 
  	break;  	 	 
  	case 4: 
    repeat=false;  	 
    break;  	 	 
    default: 
	System.out.println("Enter valid choice"); 
 	 	 	} 
 	 	} 
 	} 
 	} 
