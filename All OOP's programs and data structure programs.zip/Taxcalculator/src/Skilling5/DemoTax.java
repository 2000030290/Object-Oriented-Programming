package Skilling5;

public class DemoTax { 
	 public static void main(String[] args) {
		 TaxCalculator p1=new TaxCalculator();  p1.calculateTax(); 
	 	} 
	} 
