package class02;

public class numsum {

	public static void main(String[] args) {
		System.out.println("hello");

	}

}
