package skillfinalexam;

public class MethodOverload {
	
	   private double radius;
	   private double side;
	   private double side2;
	   public MethodOverload(double radius, double side, double side2)
	   {
		   this.radius=radius;
		   this.side=side;
		   this.side2=side2;
	   }
	

		public double area(double radius) {
			return 3.14*radius*radius;
		}
		public double area(double side,double side2) {
			return side*side2;
		}
		public String toString()
		{
			String s;
			s="Radius"+radius;
			s=s+"Side-"+side;
			s=s+"Side2-"+side2;
			return s;
		}

}
