package skillfinalexam;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		 MethodOverload m=new MethodOverload(5,6,7);
		 System.out.println("Enter radius ,side and side2 values");
		
		 System.out.println("Area of the circle is-"+m.area(sc.nextInt()));
		 System.out.println("Area of the Square is-"+m.area(sc.nextInt(),sc.nextInt()));
		 System.out.println(m.toString());
		sc.close();
			}
	}


