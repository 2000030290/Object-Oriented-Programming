package Advjavaskill7;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
public class CalculatorTest {
	TestCalci c=new TestCalci();
	@Test
	public void addtest()
	{
	int result=c.Add(5,5);
	assertEquals(10,result);
	}
	@Test
	public void subTest()
	{
	int result1=c.Sub(30,15);
	assertEquals(15,result1);
	}
	@Test
	public void mulTest()
	{
	int result2=c.Mul(10,2);
	assertEquals(20,result2);
	}
	@Test
	public void divTest()
	{
	int result3=c.Div(100,4);
	assertEquals(25,result3);
	}

}
