package Advjavaskill7;
import java.util.Scanner;
import org.junit.Test;
public class TestCalci {
public static int a,b,d,e,f,g,h,i;
public int Add(int a,int b)
{
return (a+b);
}
public int Sub(int a,int b)
{
return (a-b);
}
public int Mul(int a,int b)
{
return (a*b);
}
public int Div(int a,int b)
{
return (a/b);
}
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
TestCalci c=new TestCalci();
boolean repeat=true;
while(repeat)
{
System.out.println("***MENU***");
System.out.println("1.Addition \n2.Subtraction \n3.Multiplication \n4.Division \n5.exit");
System.out.println("Enter your choice:");
int ch=sc.nextInt();
switch(ch)
{
case 1:System.out.println("Enter 2 numbers for addition");
a=sc.nextInt();
b=sc.nextInt();
System.out.println("Sum is: "+c.Add(a, b));
break;
case 2:System.out.println("Enter 2 numbers for subtraction");
d=sc.nextInt();
e=sc.nextInt();
System.out.println("Difference is: "+c.Sub(d,e));
break;
case 3:System.out.println("Enter 2 numbers for Multiplication");
f=sc.nextInt();
g=sc.nextInt();
System.out.println("Product is: "+c.Mul(f,g));
break;
case 4:System.out.println("Enter 2 numbers for division");
h=sc.nextInt();
i=sc.nextInt();
System.out.println("Quotient is: "+c.Div(h,i));
break;
case 5:repeat=false;
break;
}
}
}
}