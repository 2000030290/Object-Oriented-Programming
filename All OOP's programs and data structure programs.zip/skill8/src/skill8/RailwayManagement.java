package skill8;
	import static org.junit.Assert.*;

	import java.util.Scanner;
	public class RailwayManagement {
	    public static void main(String a[])
	    {
	      Scanner sc=new Scanner(System.in);
	        System.out.println("enter the train number");
	        int t=sc.nextInt();
	        System.out.println("enter age");
	        int age=sc.nextInt();
	        System.out.println("enter 1 if concession required else enter 0 - ");
	        int c=sc.nextInt();
	        assert age>=0:" Age should be positive number";     
	     
	         if (c==1)                      
	         {
	         assert age>=60:" for senior citizen age should be greater than 60";    
	     
	         assert age<=120:" for sension citizen age should be less than 120";    
	        }
	    
	         assert t>=0:" Train number should be positive number";    
	         System.out.println("Congratz..........ticket booked");
	    }
	  }

