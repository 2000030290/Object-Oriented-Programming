package queue;

import java.util.Scanner;

public class Main {


		 static Queue q = new Queue(10);
		 static Scanner s = new Scanner(System.in);
		 public static void main(String args[])
		 {
		  boolean repeate = true ;
		  int ch;
		  while(repeate)
		  {
		   System.out.println("*** MENU****");
		   System.out.println("1.enqueue\n 2.dequeue\n 3.display \n 4.exit");
		   System.out.println("enter choice");
		   ch=s.nextInt();
		   switch(ch)
		   {
		   case 1 : q.enqueue(s.nextInt());
		   break;
		   case 2 : q.dequeue();
		   break;
		   case 3 : q.display();
		   break;
		   case 4 : repeate = false;
		   break;
		   
		   }
		  }

	}

}
