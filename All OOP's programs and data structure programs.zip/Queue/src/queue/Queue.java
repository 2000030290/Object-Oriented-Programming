package queue;

public class Queue <T> {
	T arr[];
	int front,rear;
	public int size;
	public Queue(int size)
	{
		arr=(T[])new Object[size];
		front=rear=-1;
		this.size=size;
	}
	
	public void enqueue(T data)
	{
		if(rear==size-1)
		{
			System.out.println("Queue is overflown");
			
		}
		else if(rear==-1)
		{
			front++;
			rear++;
			arr[rear]=data;
		}
		else
		{
			rear++;
			arr[rear]=data;
		}
	}
	public void dequeue()
	{
		if(front==-1||front>rear)
		{
			System.out.println("Queue is overflown");
			
		}
		else
		{
			System.out.println(arr[front]+"is removed");
			front++;
		}
	}
	public void display()
	{
		if(front==-1||front>rear)
		{
			System.out.println("Queue is underflown");
			
		}
		else
		{
			for(int i=front;i<=rear;i++)
				System.out.println(arr[i]);
		}
	}

	
}
