package CQ;

import java.util.Scanner;

public class Main {


		 static Scanner sc=new Scanner(System.in);
		 static Cq q = new Cq(10);

		public static void main(String[] args) {
			 boolean repeate = true ;
			  int ch;
			  while(repeate)
			  {
			   System.out.println("*** MENU****");
			   System.out.println("1.enqueue\n 2.dequeue\n 3.display \n 4.exit");
			   System.out.println("enter choice");
			 
			ch=sc.nextInt();
			   switch(ch)
			   {
			   case 1 : q.enqueue(sc.nextInt());
			   break;
			   case 2 : q.dequeue();
			   break;
			   case 3 : q.display();
			   break;
			   case 4 : repeate = false;
			   break;
			   default: System.out.println("INVALID CHOICE");
			   }
			  }

			

		}


	
}
