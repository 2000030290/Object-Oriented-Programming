package differentoperations;

public class modularization {

	public static void main(String[] args) {
    int n=5;
    int pro,sum,sump;
    
    pro=factorial(n);
	System.out.println("factorial value is="+pro);
	
    sum=sumofn(n);
    System.out.println("sum of numbers is="+sum);
    
    sump=sumofpowers(n, 2);
    System.out.println("sum of powers="+sump);
	}
	public static int factorial(int x) {
		int res=1;
		for(int i=1;i<=x;i++)
		{
			res=res*i;
		}
		return res;
	}
    public static int sumofn(int x)
    {
    	int res=0,i;
    	for(i=1;i<=x;i++)
    	{
    		res=res+i;
    	}
    	return res;
    }
    public static int sumofpowers(int x,int y)
    {
    	int res=0;
    	for(int i=1;i<=x;i++)
    	{
    		res+=Math.pow(x, y);
    	}
    	return res;
    }

}
