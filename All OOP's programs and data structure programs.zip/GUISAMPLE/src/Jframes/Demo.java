package Jframes;

public class Demo {

	public static void main(String[] args) {
		Calculator c=new Calculator();

	}

}
