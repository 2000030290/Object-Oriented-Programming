package Jframes;
import javax.swing.*;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator  implements ActionListener{
	 JFrame f;
	 JLabel l1,l2,l3;
     JTextField t1,t2,t3;
     JButton b1,b2,b3,b4;
     public Calculator()
     {
    	 f=new JFrame("My Calculator");
    	 l1=new JLabel("Input 1");
    	 l2=new JLabel("Input 2");
    	 l3=new JLabel("Output");
    	 
    	 t1=new JTextField(10);
    	 t2=new JTextField(10);
    	 t3=new JTextField(10);
    	 
    	 b1=new JButton("ADD");
    	 b2=new JButton("SUB");
    	 b3=new JButton("MUL");
    	 b4=new JButton("DIV");
    	 
    	 f.setLayout(new FlowLayout());
    	 f.add(l1);
    	 f.add(t1);
    	 f.add(l2);
    	 f.add(t2);
    	 f.add(l3);
    	 f.add(t3);
    	 f.add(b1);
    	 f.add(b2);
    	 f.add(b3);
    	 f.add(b4);
    	 f.setVisible(true);
    	 f.pack();
    	 
    	 b1.addActionListener(this);
    	 b2.addActionListener(this);
    	 b3.addActionListener(this);
    	 b4.addActionListener(this);
    
     }
     public void actionPerformed(ActionEvent a)
     {
    	 if(a.getSource()==b1)
    	 {
    		 int x=Integer.parseInt(t1.getText());
    		 int y=Integer.parseInt(t1.getText());
    		 int z=x+y;
    		 t3=setText(Integer.toString(z));
    	  
    	 }
    	 else if(a.getSource()==b2)
    	 {
    		 int x=Integer.parseInt(t1.getText());
    		 int y=Integer.parseInt(t1.getText());
    		 int z=x-y;
    		 t3=setText(Integer.toString(z));
    		 
    	 }
    	 else if(a.getSource()==b3)
    	 {
    		 int x=Integer.parseInt(t1.getText());
    		 int y=Integer.parseInt(t1.getText());
    		 int z=x*y;
    		 t3=setText(Integer.toString(z));
    		 
    	 }
    	 else if(a.getSource()==b3)
    	 {
    		 int x=Integer.parseInt(t1.getText());
    		 int y=Integer.parseInt(t1.getText());
    		 int z=x/y;
    		 t3=setText(Integer.toString(z));
    		 
    	 } 
     }
	private JTextField setText(String string) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
