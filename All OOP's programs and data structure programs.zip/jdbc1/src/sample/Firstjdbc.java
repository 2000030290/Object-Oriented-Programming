package sample;

import java.sql.*;

public class Firstjdbc {
   static final String DB_URL = "jdbc:mysql://localhost/students";
   static final String USER = "root";
   static final String PASS = "2000030290";
 
   public static void main(String[] args) {
      // Open a connection
      try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
         Statement stmt = conn.createStatement();
      ) {          

          String sql = "select * from marks";
 
         ResultSet rs = stmt.executeQuery(sql);

         while(rs.next()){
             //Display values
             System.out.print("nollno: " + rs.getInt("rollno"));
             System.out.print(", Name : " + rs.getString("name"));
             System.out.print(", Sub1: " + rs.getInt("sub1"));
             System.out.println(", Sub2: " + rs.getInt("sub2"));
          }
       } catch (SQLException e) {
          e.printStackTrace();
       } 


   }
}