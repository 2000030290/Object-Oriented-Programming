package lab_7_2;

public class TwoDShape extends Shape {
final int dimenction=0;
	
	public int getDimenction() {
		return dimenction; 
	}
}
