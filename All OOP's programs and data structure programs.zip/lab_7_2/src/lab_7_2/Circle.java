package lab_7_2;

public class Circle extends TwoDShape {
	private double radius;
	public void setRadius(double radius) 
	{
		this.radius=radius;
	}
	public String toString() {
		String s;
		s="Circle:"+"\nBorder Width:"+getBWidth()+" Border Color:"+getBColor();
		s=s+" Fill:"+getFill()+"\nDimenctions:"+getDimenction()+" Radius:"+radius;
		return s;
	}

}
