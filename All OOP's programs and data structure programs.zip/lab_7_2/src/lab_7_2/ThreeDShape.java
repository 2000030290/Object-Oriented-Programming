package lab_7_2;

public class ThreeDShape extends Shape{
	int dimenction;
	public void setDimenction(int dim) {
		 this.dimenction=dim;
	}
	public int getThreeD() {
		return dimenction; 
	}
}
