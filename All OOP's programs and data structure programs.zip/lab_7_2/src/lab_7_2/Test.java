package lab_7_2;

public class Test {

	public static void main(String[] args) {
		
		
			Rectangle s1=new Rectangle();
			s1.setBorderWidth(5);
			s1.setBorderColor("Yellow");
			s1.setFillColor("black");
			s1.setFill(true);
			s1.setLength(15);
			s1.setBorderWidth(20);
			System.out.println(s1);
			Circle s2=new Circle();
			s2.setBorderWidth(5);
			s2.setBorderColor("Yellow");
			s2.setFillColor("black");
			s2.setFill(true);
			s2.setRadius(15);
			s2.setBorderWidth(20);
			System.out.println(s2);

	}

}
