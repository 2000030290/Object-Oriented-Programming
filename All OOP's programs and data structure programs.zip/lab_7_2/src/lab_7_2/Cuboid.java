package lab_7_2;

public class Cuboid extends ThreeDShape {
	private double length,breadth,height;
	public void setCudoid(double l,double b,double h) {
		this.length=l;
		this.breadth=b;
		this.height=h;
	}
	public String toString() {
		String s;
		s="Cuboid:"+"\nBorder Width:"+getBWidth()+" Border Color:"+getBColor();
		s=s+" Fill:"+getFill()+"\nDimenctions:"+getThreeD()+" Length="+length;
		s=s+" Breadth="+breadth+" Height="+height;
		return s;
	}

}
