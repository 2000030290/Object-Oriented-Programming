package lab_7_2;

public class Rectangle extends TwoDShape {
	private double length,breadth;
	public void setLength(double l) {
		this.length=l;
	}
	public void setBreadth(double b) {
		this.breadth=b;
	}
	public String toString() {
		String s;
		s="Rectangle:"+"\nBorder Width:"+getBWidth()+" Border Color:"+getBColor();
		s=s+" Fill:"+getFill()+" Fill Color:"+getFColor()+"\nDimenctions:"+getDimenction()+" Length="+length+" Breadth"+breadth;
		return s;
	}

}
