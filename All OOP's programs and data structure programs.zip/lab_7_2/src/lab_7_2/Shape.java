package lab_7_2;

public class Shape {
	private double borderWidth;
	private String borderColor,fillColor;
	private boolean fill;
	public void setBorderWidth(double width) {
		this.borderWidth=width;
	}
	public void setBorderColor(String color) {
		this.borderColor=color;
	}
	public void setFillColor(String fillColor) {
		this.fillColor=fillColor;
	}
	public void setFill(boolean fill) {
		this.fill=fill;
	}
	public double getBWidth() {
		return borderWidth; 
	}
	public String getBColor() {
		return borderColor; 
	}
	public String getFColor() {
		return borderColor; 
	}
	public boolean getFill() {
		return fill;
	}

}
