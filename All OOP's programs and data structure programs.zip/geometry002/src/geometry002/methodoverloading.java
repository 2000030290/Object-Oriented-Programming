package geometry002;

public class methodoverloading {

}
