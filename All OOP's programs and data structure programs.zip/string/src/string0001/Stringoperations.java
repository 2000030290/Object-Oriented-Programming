package string0001;

public class Stringoperations {

	public static void main(String[] args) {
	
    String name="abcysgiy";
    System.out.println(name.toUpperCase());
    String name2="KJHFLISUHjfoij";
    System.out.println(name2.toLowerCase());
    String name3="AKHILESH";
    System.out.println(name3.startsWith("AK"));
    String name4="akash";
    System.out.println(name4.endsWith("k"));
    System.out.println(name3.equals(name4));
    String name5="joshef";
    System.out.println(name5.charAt(3));
    String name6="ajay";
    System.out.println(name6.indexOf("j"));
    String name7="kluniversity";
    System.out.println(name7.lastIndexOf("i"));
    String name8="universitystudent";
    System.out.println(name8.substring(2));
    String name9="  we are  students  ";
    System.out.println(name9.trim().length());
    
	}

}
