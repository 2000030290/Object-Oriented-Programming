package Code;

public class Node<T> {
	T data;
	Node<T>next;
	public Node(T data) {
		this.data=data;
		next=null;
	}
	Node<T>front=null;
	Node<T>rear=null;
	public void enqueue(T d)
	{
		Node<T> n=new Node(d);
		if(front==null && rear==null)
		{
			front=rear=n;
			
		}
		else
		{
			rear.next=n;
			rear=n;
		}
	}
	public void dequeue()
	{
		if(front==null && rear==null)
			System.out.println("Queue is underflown");
		else
			System.out.println(front.data+"is removed");
		    front=front.next;
	}
	public void display()
	{
		Node<T>tmp=front;
	    while(tmp!=null)
	    {
	    	System.out.println(tmp.data);
	    	tmp=tmp.next;
	    }
	}

}
