package Binarysearchtree;

import java.util.Scanner;

public class Main 
{
	  static TreeOperations  T= new TreeOperations ();
	  static Scanner sc=new Scanner(System.in);
	  public static void main(String[] args) {
	        boolean repeat=true;
	        int choice;
	        while(repeat)
	        {
	         System.out.println("* MENU**");
	         System.out.println("1.INORDER");
	         System.out.println("2.PRERDER");
	         System.out.println("3.POSTORDER");
	         System.out.println("4.MINIMUM");
	         System.out.println("5.MAXIMUM");
	         System.out.println("6.SEARCH");
	         System.out.println("7.INSERT");
	         System.out.println("8.DELETE");
	         System.out.println("9.EXIT");
	         System.out.println("ENTER UR CHOICE");
	         choice=sc.nextInt();
	         switch(choice)
	         {
	         case 1: T.inorder(T.root);
	         break;
	         case 2: T.preorder(T.root);
	         break;
	         case 3: T.postorder(T.root);
	         break;
	         case 4: System.out.println("minimum element is "+T.minimum(T.root));
	         break;
	         case 5: System.out.println("maximum element is "+T.maximum(T.root));
	         break;
	         case 6: T.search(T.root, sc.nextInt());
	         break;
	         case 7:System.out.println("enter data");
	         T.root= T.insert(T.root, sc.nextInt());
	         break;
	         case 8:T.deleteNode(T.root, sc.nextInt());
	         break;
	         case 9: repeat=false;
	         break;
	         default :
	         System.out.println("invalid input");
	         break;
	    }
	  }
	  }
	  }

