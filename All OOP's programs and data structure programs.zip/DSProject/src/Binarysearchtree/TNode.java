package Binarysearchtree;

public class TNode {
	 TNode left;
	 int data;
	 TNode right;
	 public TNode(int data)
	 {
	  this.data=data;
	  left=right=null;
	 }
}
