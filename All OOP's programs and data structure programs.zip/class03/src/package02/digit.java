package package02;

public class digit {
	public static int numOfDigits(int x)
	{
		int res=0;
		do {
			res++;
			x=x/10;
		}
		while(x>0);
		return res;
		
	}
	public static int sumOfDigits(int x)
	{
		int res=0;
		while(x>0)
		{
			
			res=res+(x%10);
	     	x=x/10;
		}
		return res;
	}
	public static boolean isEven(int x)
	{
	if(x%2==0) return true;
	return false;
	}
}
