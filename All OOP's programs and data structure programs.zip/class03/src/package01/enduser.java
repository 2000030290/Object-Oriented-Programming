package package01;
import package02.digit;
public class enduser {

	public static void main(String[] args) {
	 int num=291;
	 System.out.println("number of digits="+digit.numOfDigits(num));
	 System.out.println("sum of digits="+digit.sumOfDigits(num));
	 System.out.println(digit.isEven(num)? "the number "+num+"is"+"even":"the number"+num+"is odd");
	}

}
