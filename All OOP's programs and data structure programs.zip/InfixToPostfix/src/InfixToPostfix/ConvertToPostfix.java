package InfixToPostfix;
import java.util.Scanner;
import java.util.Stack;
public class ConvertToPostfix {
	  static String infixEx;
	   static String postfixEx;
	   static Stack<Character> s;
	   public static void main(String[] args) {
	   Scanner sc=new Scanner(System.in);
	   System.out.println("enter expression");
	   infixEx=sc.next();
	   postfixEx = new String();
	   s=new Stack(20);
	   }
	   void InfixToPostfix(){
	   System.out.println(postfixEx);
	   }
	   {
	   for(int i=0; i<infixEx.length(); i++) {
	   char c=infixEx.charAt(i);
	   if(c=='(') {
	   s.push(c);
	   }
	   else if(Character.isLetterOrDigit(c)) {
	   postfixEx+=c;
	   }
	   else if(c==')') {
	   while(s.top!=-1 && s.peek()!='(') {
	   char x=s.pop();
	   postfixEx+=x;
	   }
	   s.pop(); 
	   }
	   else if(c=='+' ||c=='-' ||c=='*' ||c=='/' || c=='^'
	   || c=='%') {
	   while(s.top!=-1 && s.peek()!='(' && 
	   getPriority(s.peek())>=getPriority(c)) {
	   char x=s.pop();
	   postfixEx+=x;
	   }
	   s.push(c);
	   }
	   }
	   while(s.top!=-1) {
	   postfixEx+=s.pop();
	   }
	   }
	   public static int getPriority(char ch) {
	   if(ch=='^') {
	   return 2; 
	   }
	   else if(ch=='*' || ch=='/' || ch=='%') {
	   return 1;
	   }
	   else {return 0;
	   }
	   }
	  }