package InfixToPostfix;

public class Stack <T> {
	 Character s[];
	   int size;
	   int top;
	   public Stack(int size) {
	   this.size=size;
	   s=new Character[20];
	   this.top=-1;
	   }
	   public boolean isEmpty() {
	   if(top==-1) {
	   return true;
	   }
	   else {
	   return false;
	   }
	   }
	   public void push(Character ele) {
	   if(top==size-1) {
	   System.out.println("stack is overflown");
	   }
	   else {
	   top++;
	   s[top]=ele;
	   }
	   }
	   public Character pop() {
	   if(isEmpty()) {
	   return 0;
	   }
	   else {
	   char x= s[top];
	   top--;return x;
	   }
	   }
	   public Character peek() {
	   if(isEmpty()) {
	   return 0;
	   }
	   else
	   return s[top];
	   }
	  }