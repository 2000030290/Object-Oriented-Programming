package sample;

public class GeometricShape {
  String boarderColor;
  boolean filled;
}
