package sample;

public class Rectangle extends GeometricShape {
 double length;
 double breadth;
 public String toString() {
	 String s;
	 s="Length="+length;
	 s=s+"\nbreadth="+breadth;
	 s=s+"\nBoarderColor="+boarderColor;
	 s=s+"\nFilled"+filled;
	 return s;
 }
}
