package sample;

public class Demo {

	public static void main(String[] args) {
	  Rectangle r=new Rectangle();
	  r.length=45;
	  r.breadth=50;
	  r.boarderColor="red";
	  r.filled=false;
	  System.out.println(r);

	}

}
