package Sorting;

import java.util.Scanner;

public class ShellSort {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array");
		int n=sc.nextInt();
		System.out.println("Enter elements into the array");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		shellSorting(a);
		System.out.println("After sorting");
		for(int i=0;i<n;i++)
		System.out.println(a[i]);
		
	}

	private static void shellSorting(int a[]) {
        int tmp,j;		
		for(int gap=a.length/2;gap>=1;gap=gap/2)
		{
			for(int i=gap;i<a.length;i++)
			{
				tmp=a[i];
				for(j=i-gap;j>0&&tmp<a[j];j=j-gap)
				{
					a[j+gap]=a[j];
				}
				a[j+gap]=tmp;
			}
		}
		
	}

}
