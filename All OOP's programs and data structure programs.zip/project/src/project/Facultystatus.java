package project;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;


import javax.swing.*;


public class Facultystatus  implements ActionListener {
	 JFrame f;
	 JLabel l1,l2;
     JTextField t1,t2;
     JButton b1;
     File f1=new File("C:\\Users\\DELL\\eclipse-workspace\\project\\src\\project\\section6.txt");
     File f2=new File("C:\\Users\\DELL\\eclipse-workspace\\project\\src\\project\\section7.txt");
     File f3=new File("C:\\Users\\DELL\\eclipse-workspace\\project\\src\\project\\section8.txt");
     public Facultystatus ()
     {
    	 f=new JFrame("Students feedback on faculty");
    	 l1=new JLabel("Section Number");
    	 l2=new JLabel("Faculty Details");
    	 
    	 t1=new JTextField(15);
    	 t2=new JTextField(100);
    	 
    	 b1=new JButton("Enter");
    	
    	 f.setLayout(new FlowLayout());
    	 f.add(l1);
    	 f.add(t1);
    	 f.add(l2);
    	 f.add(t2);
    	 f.add(b1);
    	
    	 f.setVisible(true);
    	 f.pack();
    	 
    	 b1.addActionListener(this);

     }
     public void actionPerformed(ActionEvent a)
     {
    	 String display="";
    	 if(a.getSource()==b1) 
    	 {
    			
    			int s=Integer.parseInt(t1.getText());
    			if(s==6) {
    				
    				try {
						Scanner fc=new Scanner(f1);
						String t;
						while(fc.hasNext()) {
							 t = fc.nextLine();
							display += t;
						}
						fc.close();
						t2.setText(display);
						
					} catch (FileNotFoundException e) {
						
						e.printStackTrace();
					}
    				
    				
    			}
    			else if(s==7) {
    				
    				try {
						Scanner fc=new Scanner(f2);
						String t;
						while(fc.hasNext()) {
							t = fc.nextLine();
							display += t;
						}
						fc.close();
						t2.setText(display);
						
					} catch (FileNotFoundException e) {
						
						e.printStackTrace();
					}
    				
    			}
    			else if(s==8) {
    				
    				try {
						Scanner fc=new Scanner(f3);
						String t;
						while(fc.hasNext()) {
							t = fc.nextLine();
							display += t;
						}
						fc.close();
						t2.setText(display);
						
					} catch (FileNotFoundException e) {
						
						e.printStackTrace();
					}
    				
    			}
    			else
    			{
    				t2.setText("Invalid Section Number");
    			}
    		
    		 
    	 }
    	 
    	
     }
	
}
