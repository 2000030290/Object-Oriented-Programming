package project;

public class Demo {

	public static void main(String[] args) {
		 Facultystatus f=new Facultystatus();
	

	}
	

}
