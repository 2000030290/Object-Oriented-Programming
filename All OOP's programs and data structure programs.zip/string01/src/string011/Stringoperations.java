package string011;

import java.util.Scanner;

public class Stringoperations {

	public static void main(String[] args) {
	Scanner s= new.Scanner(System.in);
	 String name1=s.next();
	 String name2=s.next();
	 string name3=name1+name2;
	 System.out.println(name3);
	}

}
