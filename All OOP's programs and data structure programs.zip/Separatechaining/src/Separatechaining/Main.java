package Separatechaining;

import java.util.Scanner;

public class Main {
		static Scanner sc=new Scanner(System.in);
	    static Separatechaining sep= new  Separatechaining(10);
	    public static void main(String[] args) {
	    	boolean repeat=true;
			int choice;
			while (repeat)
			{
				System.out.println("***MENU***");
				System.out.println("1.INSERT AN ELEMENT");
				System.out.println("2.DISPLAY ELEMENTS");
				System.out.println("3.EXIT");
				System.out.println("ENTER YOUR CHOICE");
				choice=sc.nextInt();
				switch(choice)
				{
					case 1:
						System.out.println("Enter element to be inserted");
						sep.insert(sc.nextInt());
						break;
					case 2: sep.display();
					    break;
					case 3:
						repeat=false;
						break;
					default:System.out.println("INVALID CHOICE");
				}
			}
	    }
} 