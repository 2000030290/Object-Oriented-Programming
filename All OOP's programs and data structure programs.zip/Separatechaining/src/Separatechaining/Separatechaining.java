package Separatechaining;

public class Separatechaining {
	Node ht[];
	int size;
	public Separatechaining(int size)
	{
		this.size=size;
		ht=new Node[size];
		for(int i=0;i<size;i++)
			ht[i]=null;
	}
	public void insert(int key)
	{
		int index=key%size;
		Node n=new Node(key);
		if(ht[index]==null)
			ht[index]=n;
		else
		{
			Node t=ht[index];
			while(t.next!=null)
			t=t.next;
			t.next=n;
		}
	}
	public void display()
	{
		for(int i=0;i<size;i++)
		{
			System.out.println("Index"+i);
			Node t=ht[i];
			while(t!=null) {
				System.out.println(t.data);
				t=t.next;
			}
		}
	}

}
