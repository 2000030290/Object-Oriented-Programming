package twodshapes;

public class rectangle {
	//members
		private static double length=10, breadth=15;
		private static String color="Red";
		
		//methods
		private static double calcArea() {
			
			return length*breadth;
		}
		
		public static double calcPeri() {
			return 2*(length+breadth);
		}
		
		public static String dispaly() {
			String res;
			res="Area of rectangle="+calcArea();
			res=res+"Perimeter of rectangle"+calcPeri();
			return res;
		}

	
}
