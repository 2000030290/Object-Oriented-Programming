package twodshapes;

public class circle {

	//members
	private static double radius=10;
	private static String color="Yellow";
		
	//methods
	private static double calcArea() {
		double result = 3.14*radius*radius;
		
		return result;
	}
	
	private static double calcPeri() {
		double result = 3.14*2*radius;
		return result;
	}
	
	public static String display() {
		String res;
		res="Area of Circle="+calcArea();
		res=res+"Perimeter of Circle"+calcPeri();
		return res;
	}

}


