package endUser;

import twodshapes.*;

import twodshapes.circle;
import twodshapes.rectangle;
public class endUser {

	public static void main(String[] args) {
		
boolean isCircle = true;
		
		if (isCircle) {
			System.out.println(circle.display());
					
		}
		else {
			System.out.println(rectangle.calcPeri());
		}
	}
	

}
