package packade01;
import package02.circle;
import package02.rectangle;
public class enduser {

	public static void main(String[] args) {
	
		boolean iscircle=false;
		if(iscircle) {
			System.out.println(circle.display());
		}
			else {
		   System.out.println(rectangle.display());		
			
		}
	}

}