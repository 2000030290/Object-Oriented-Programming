package package02;

public class circle {

//members
private static double radius=10;
private static String color="Yellow";
//methods
public static double calcArea() {
	double result =3.14*radius*radius;
	return result;
}
private static double calcPeri() {
	double result=2*3.14*radius;
	return result;
}
public static String display() {
	String res = String. format("the area of circle=%.2f%n the perimeter of the circle=%.2f%n It is %s circle%n",calcArea(),calcPeri(),color);
	return res;		
}
}
