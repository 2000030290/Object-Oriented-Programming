package package02;

public class rectangle {

	private static double length=10,breadth=15;
	private String color ="red";
	
	private static double calcArea() {
		return length*breadth;
	}
	public static double calcPeri() {
	double length=20,breadth=30;
		return 2*(length+breadth);
		
	}
	public static String display() {
		String res=String.format("The area of rectangle=%.1f%n The perimeter=%.1f%n It is %s rectangle %n",calcArea(),calcPeri,color);
		return res;
	}
}
