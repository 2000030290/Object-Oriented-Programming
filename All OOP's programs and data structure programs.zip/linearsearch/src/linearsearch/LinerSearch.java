package linearsearch;

import java.util.Scanner;

public class LinerSearch {
	  static int a[];
	    static int size;
	    
	    static int LinearSearch( int key) {
	      for(int i=0;i<size;i++) {
	        if(a[i]==key) {
	          return i;
	        }
	      }
	      return -1;
	      
	    }
	    public static void main(String[] args) {
	      Scanner sc= new Scanner(System.in);
	      System.out.println("Enter Size");
	      size =sc.nextInt();
	      a=new int[size];
	      System.out.println("enter array values");
	       
	       
	      for( int i=0;i<size;i++) {
	        a[i]=sc.nextInt();
	            
	      }
	      System.out.println("enter key");
	        int key=sc.nextInt();
	        int b=LinearSearch(key);
	      if(b== -1) {
	        System.out.println("not found");
	      }
	      else {
	        System.out.println("element is found in array"+(b+1));
	      }
	         
	    }
	}