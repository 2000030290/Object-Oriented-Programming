package strings00;

import java.util.Scanner;

public class count {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String name=s.next();
		System.out.println(name.length());

	}

}
