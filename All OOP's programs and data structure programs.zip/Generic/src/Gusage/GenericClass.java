package Gusage;

public class GenericClass<T>{
	private T data;
	public GenericClass(T data)
	{
		this.data=data;
	}
	public T getData()
	{
		return this.data;
	}

	public static void main(String[] args) {
	
		GenericClass<Integer>intobj=new GenericClass<>(5);
		System.out.println("Generic class returns:" +intobj.getData());
		
		GenericClass<String>Stringobj=new GenericClass<>("Java Programming");
		System.out.println("Generic class returns:" +Stringobj.getData());
		
		GenericClass<Double>floatobj=new GenericClass<>(57.6);
		System.out.println("Generic class returns:" +floatobj.getData());

	}

}
