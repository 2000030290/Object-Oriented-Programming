package singlelinkedlistLAB;

import java.util.Scanner;

public class Sll<T> {
				Node<Integer> start = null; 
			     public void create() 
			     { 
			       char choice; 
			       int d; 
			       Scanner sc=new Scanner(System.in); 
			       Node<Integer> latest=null; 
			       do {  
			         System.out.println("enter the data");
			         d=sc.nextInt(); 
			         Node<Integer> n=new Node<Integer> (d); 
			         if(start==null) 
			         { 
			           start=n; 
			           latest=n;
			         } 
			         else  
			         { 
			           latest.next=n; 
			           latest=n;
			         } 
			         System.out.println("do you want to continuosly? Y or No"); 
			         choice=sc.next().charAt(0); 
			       } 
			       while(choice=='Y' || choice=='y');        
			       }
			     public void insertBegining(T d)
			     {
			      Node<Integer>n=new Node<Integer>((Integer) d);
			      n.next=start;
			      start=n;
			     }
			     public void deleteBegin()
			     {
			      System.out.println(start.data+"is deleted");
			      start=start.next;
			     }
			     public void insertEnd(T d)
			     {
			      Node<Integer> n=new Node<Integer>((Integer) d);
			      Node<Integer>t=start;
			      while(t.next!=null) {
			       t=t.next;
			      }
			     t.next=n;
			  }
			     public void display()
			     {
			      Node<Integer>t=start;
			      while(t!=null)
			      {
			       System.out.println(t.data);
			       t=t.next;
			      }
			     }
			      public int count()
			      {
			      int c=0;
			       Node<Integer>t=start;
			       while(t!=null)
			       {
			        c++;
			        t=t.next;
			       }
			       return c;
			      }
			      public void deleteEnd()
			      {
			       Node<Integer>t=start;
			       while(t.next.next!=null)
			        t=t.next;
			       System.out.println(t.data+"is deleted");
			       t.next=null;
			      }
			      public boolean search(int key) {
			          Node<Integer> t=start;
			          while(t!=null) {
			            if(t.data==key)
			              return true;
			            t=t.next;
			          }
			          return false;
			        }
}