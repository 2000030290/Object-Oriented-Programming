package singlelinkedlistLAB;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	      Sll qq=new Sll();
	    while(true)
	    {
	    System.out.println("*** Menu ***");
	    System.out.println("1.Creat");
	    System.out.println("2.Insert");
	    System.out.println("3.deletion");
	    System.out.println("4.Display");
	    System.out.println("5.Search");
	    System.out.println("6.Exit");
	    System.out.println("Enter your choice");
	    int cho=sc.nextInt();
	    switch(cho)
	    {
	    case 1: 
	      qq.create();
	    break;
	    case 2: 
	      System.out.println("enter 1 for insert at begining 2 for at end");
	      int ch=sc.nextInt();
	      switch(ch) {
	      case 1:qq.insertBegining(sc.nextInt());
	      break;
	      case 2: qq.insertEnd(sc.nextInt());
	      break;
	    }
	    break;
	    case 3:
	      System.out.println("enter 1 for insert at begining 2 for at end");
	      int c=sc.nextInt();
	      switch(c) {
	      case 1: qq.deleteBegin();
	      break;
	      case 2:
	        qq.deleteEnd();
	        break;
	      }
	      break;
	    case 4: qq.display();
	    break;
	    case 5: 
	      System.out.println("enter number to search");
	      qq.search(sc.nextInt());
	    break;
	    case 6: System.exit(0);
	    default:System.out.println("Enter the number from 1 to 6 only");
	    }
	    }

	  }

}
