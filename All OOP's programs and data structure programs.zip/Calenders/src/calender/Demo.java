package calender;
import java.util.Scanner;
import java.util.Calendar;
public class Demo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    System.out.println("Ente id");
	    long id=sc.nextLong();
	    System.out.println("Enter name");
	    String name=sc.next();
	    System.out.println("Enter gender");
	    char gender=sc.next().charAt(0);
	    System.out.println("Enter date ");
	    int d=sc.nextInt();
	    System.out.println("Enter Month ");
	    int m=sc.nextInt();
	    System.out.println("Enter Year ");
	    int y=sc.nextInt();
	    System.out.println("Enter marks of 6 subjects");
	    int marks[]=new int[6];
	    for(int i=0;i<=5;i++)
	    marks[i]=sc.nextInt();
	    Calendar c=Calendar.getInstance();
	    c.set(y,m,d);
	    Student s=new Student(id,name,gender,c,marks);
	    System.out.println(s);
	    	
	}

}
