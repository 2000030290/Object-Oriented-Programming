package lab8__1;

public class Demo {

	public static void main(String[] args) {
		
			Triangle t=new Triangle("red",true);
			t.setSides(14, 15, 16);
			System.out.println(t.toString());
			

	}

}
