package lab8__1;

public class Triangle  extends GeometricObject{
	private double s1,s2,s3;
	public Triangle(String color,boolean filled)
	{
	
		super(color,filled);
		this.s1=this.s2=this.s3=1;
		
	}
	public double gets1()
	{
		return s1;
	}
	public double gets2()
	{
		return s2;
	}
	public double gets3()
	{
		return s3;
	}
	public void setSides(double s1,double s2,double s3) {
		this.s1=s1;
		this.s2=s2;
		this.s3=s3;

	}
	public double getArea()
	
	{
		double s=(s1+s2+s3)/2;
		double area=Math.sqrt(s*(s-s1)*(s-s2)*(s-s3));
		return area;
	}
	public double getPerimeter() {
		double p=s1+s2+s3;
		return p;
	}
	public String toString() {
		String s="Triangle:side1="+s1+"\nside2="+s2+"\nside3="+s3+"\nArea of triangle="
	+getArea()+"\nPerimeter of triangle"+getPerimeter()+"Color="+getcolor()+" Filled="+getfilled();
		return s;
	


}
}
