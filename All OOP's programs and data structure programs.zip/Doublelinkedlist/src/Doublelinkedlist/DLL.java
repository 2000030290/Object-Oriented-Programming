package Doublelinkedlist;

public class DLL {
	DNode head=null;
	 public void insertAtBeg(int x) {
	 DNode newNode=new DNode(x);
	 if(head==null) {
	 head=newNode;
	 }
	 else {
	 newNode.next=head;
	 head=newNode;
	 head.next.prev=head; }
	 }
	 public void insertAtEnd(int x){
	 DNode newNode=new DNode(x);
	 if(head==null) {
	 head=newNode;
	 }
	 else {
	 DNode temp=head;
	 while(temp.next!=null) {
	 temp=temp.next;
	 }
	 temp.next=newNode;
	 newNode.prev=temp;
	 }
	 }
	 public void insertAtMid(int x,int p) {
	 DNode newNode=new DNode(x);
	 if(head==null) {
	 head=null;
	 }
	 else {
	 int c=1;
	 DNode temp=head;
	 while(c!=p-1&&temp.next!=null) {
	 temp=temp.next;
	 c++;
	 }
	 DNode temp2=temp.next;
	 newNode.prev=temp;
	 newNode.next=temp2;
	 temp.next=newNode;
	 temp2.prev=newNode;
	 }
	 }
	 public void deleteAtBeg() {
	 if(head==null) {
	 System.out.println("No Element to Delete");
	 }
	 else {
	 head=head.next;
	 head.prev=null; }
	 }
	 public void deleteAtEnd() {
	 if(head==null) {
	 System.out.println("No Element to Delete");
	 }
	 else {
	 DNode temp=head;
	 while(temp.next!=null) {
	 temp=temp.next;
	 }
	 temp=temp.prev;
	 temp.next=null;
	 }
	 }
	 public void deleteAtMid(int p) {
	 if(head==null)
	 System.out.println("No Elements to Delete");
	 else {
	 int c=1;
	 DNode temp=head;
	 while(c!=p-1&&temp.next!=null) {
	 temp=temp.next;
	 c++;
	 }
	 temp.next.next.prev=temp;
	 temp.next=temp.next.next;
	 }
	 }
	 public void display() {
	 if(head==null)
	 System.out.println("No Elements to Delete");
	 else {
	 DNode temp=head;
	 while(temp!=null) {
	 System.out.println(temp.data);
	 temp=temp.next;
	 }
	 }
	 }
	 public void displayReverse() {
	 if(head==null) System.out.println("No Elements to Delete");
	 else {
	 DNode temp=head;
	 while(temp.next!=null) {
	 temp=temp.next;
	 }
	 while(temp.prev!=null) {
	 System.out.println(temp.data);
	 temp=temp.prev;
	 }
	 }
	 }

}
