package Doublelinkedlist;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
		 DLL ob=new DLL();
		 boolean b=true;
		 while(b) {
		 System.out.println("****Menu****");
		 System.out.println("1) Insert At Beg");
		 System.out.println("2) Insert At Middle");
		 System.out.println("3) Insert At End");
		 System.out.println("4) Delete At Beg");
		 System.out.println("5) Delete At Middle");
		 System.out.println("6) Delete At End");
		 System.out.println("7) Display");
		 System.out.println("8) Display in Reverse");
		 System.out.println("Enter UR Choice");
		 int ch=sc.nextInt();
		 switch(ch) {
		 case 1: System.out.println("Enter data");
		 int x=sc.nextInt();
		 ob.insertAtBeg(x);
		 break;
		 case 2: System.out.println("Enter position");
		 int p=sc.nextInt();
		 System.out.println("Enter data");
		 int t=sc.nextInt();
		 ob.insertAtMid(t,p);
		 break;
		 case 3: System.out.println("Enter data");
		 int q=sc.nextInt();
		 ob.insertAtEnd(q); break;
		 case 4: ob.deleteAtBeg();
		 break;
		 case 5: System.out.println("Enter position");
		 int o=sc.nextInt();
		 ob.deleteAtMid(o);
		 break;
		 case 6: ob.deleteAtEnd();
		 break;
		 case 7: ob.display();
		 break;
		 case 8: ob.displayReverse();
		 break;
		 default: System.out.println("Enter Valid Choice");
		 b=false;
		 }
		 }
		 sc.close();
		 

	}

}
