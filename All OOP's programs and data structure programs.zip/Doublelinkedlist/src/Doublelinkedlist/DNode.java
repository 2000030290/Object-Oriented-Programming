package Doublelinkedlist;

public class DNode {
 
	 int data;
	 DNode next;
	 DNode prev;
	 DNode(int x){
	 this.data=x;
	 this.next=null;
	 this.prev=null;
}
}
