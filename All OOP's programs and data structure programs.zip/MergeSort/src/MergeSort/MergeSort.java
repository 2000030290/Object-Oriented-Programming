package MergeSort;

import java.util.Scanner;

public class MergeSort {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array");
		int n=sc.nextInt();
		System.out.println("Enter elements into the array");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
     	MergeSort(a);
		System.out.println("After sorting");
		for(int i=0;i<n;i++)
		System.out.println(a[i]);
	}
	private static void MergeSort(int[] a) {
	
		int mid;
		int low ,high;
		if(low<high)
		{
			mid=(low+high)/2;
		}
		partition(a,low,mid);
		partition(a,mid+1,high);
		merge(a,low,mid,high);
	}
	private static void partition(int[] a, int low, int mid ,int high) {
		int i=low,j=mid+1;
		
	}

}
