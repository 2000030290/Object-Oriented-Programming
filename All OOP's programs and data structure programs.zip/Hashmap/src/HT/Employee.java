package HT;
import java.util.HashMap;
public class Employee {

	public static void main(String[] args) {
		HashMap<String,String>emp=new HashMap<String,String>();
		emp.put("1111","Akhilesh");
		emp.put("2222","Avinash");
		emp.put("3333","Vinay babu");
		emp.put("4444","Pavan");
		emp.put("5555","Akash");
		emp.put("6666","Ram");
		System.out.println(emp);
		
		String name=emp.get("1111");
		System.out.println(name);
		
		emp.remove("5555");
		System.out.println(emp);
		
		emp.replace("4444","Anand");
		System.out.println(emp);
		
		System.out.println(emp.size());
		
	//	emp.clear();
    //	System.out.println(emp);
		System.out.println(emp.values());
		System.out.println(emp.keySet());
		
		for(String i:emp.values())
		{
			System.out.println(i);
		}
		for(String i:emp.keySet())
		{
			System.out.println(i);
		}
	}
}
