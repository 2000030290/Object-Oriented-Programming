package lab5_01;
import java.io.File;
import java.util.Scanner;
import java.util.StringTokenizer;


public class FileWord {

	public static void main(String[] args)throws Exception  {
				      File f=new File("C:\\Users\\DELL\\eclipse-workspace\\lab5_01\\src\\lab5_01\\Data.txt");
				      Scanner sc=new Scanner(f);
				      int count=0,total=0,i=1;
				      while(sc.hasNextLine())
				      {
				        
				        String s=sc.nextLine();
				        StringTokenizer p=new StringTokenizer(s," ");
				        count=p.countTokens();
				        total=total+count;
				        System.out.println("Line" +i +"\t" +count +"\t" +s);
				        i++;
				      
				        
				      }
				      System.out.println(total);
				      sc.close();
				      

				   

	}

}
