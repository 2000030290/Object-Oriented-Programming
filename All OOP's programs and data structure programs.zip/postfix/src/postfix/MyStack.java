package postfix;

public class MyStack {
	int s[];
	int top;
	int size;
	public  void Mystack(int size)
	{
		this.size=size;
		s=new int[size];
		top=-1;
	}
	public boolean isEmpty()
	{
		if(top==-1)
			return true;
		else
			return false;
	}
	public void push(int ele)
	{
		if(top==size-1)
		{
			System.out.println("Stack is overflow");
		}
		else
		{
			top++;
			
			s[top]=ele;
		}
	}
	public void pop()
	{
		if(top==-1)
		{
			System.out.println("Stack is underflow");
			
		}
		else
		{
			System.out.println(s[top]+"is delected");
			top--;
			
		}
		
	}
	public void peek()
	{
		if(top==-1)
		{
			System.out.println("Stack is underflow");
			
		}
		else
		{
			System.out.println(s[top]+"is the peek element");
		}
	}
	public void display()
	{
		if(top==-1)
		{
			System.out.println("Stack is underflow");
			
		}
		else
		{
			for(int i=top;i>=0;i--)
				System.out.println(s[i]);
		}
	}


}
