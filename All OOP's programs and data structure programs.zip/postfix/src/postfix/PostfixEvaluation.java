package postfix;
import java.util.Scanner;

public class PostfixEvaluation {
	static Scanner sc;
	static String postfix;
	static MyStack s;

	public static void main(String[] args) {
		sc=new Scanner (System.in);
		System.out.println("Enter the postfix form");
		postfix=sc.next();
		s=new MyStack<Integer>();
		int a,b,c=0;
		for(int i=0;i<postfix.length();i++)
		{
			if(Char)
		}
		
	 

	}

}
