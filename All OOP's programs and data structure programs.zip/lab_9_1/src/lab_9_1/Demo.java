package lab_9_1;
import java.util.Scanner;
public class Demo {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	Point p[]=new Point[10];
	int count=0;
	boolean b=true;
	while(b)
	{
	System.out.println("MENU");
	System.out.println("1.Line");
	System.out.println("2.Rectangle");
	System.out.println("3.Circle");
	System.out.println("4.Display");
	System.out.println("5.Exit");
	System.out.println("Enter your Choice");
	int ch=sc.nextInt();
	switch(ch)
	{
	case 1:
	System.out.println("Enter X1 and Y1 and X2 and Y2");
	p[count++]=new Line(sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
	break;
	case 2:
	System.out.println("Enter X1 and Y1 and X2 and Y2");
	p[count++]=new Rectangle(sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
	break;
	case 3:
	System.out.println("Enter X1 and Y1 and Radius");
	p[count++]=new Circle(sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
	       break;
	case 4:
	System.out.println("************");
	for(int i=0;i<count;i++)
	{
	p[i].show();
	System.out.println("************");
	}
	break;
	case 5:
	b=false;
	break;
	default:
	System.out.println("Invalid choice");
	}
	}
	sc.close();

	}

}