package lab_9_1;

public class Circle extends Point {
	 protected double radius;
	  Circle(double x1,double y1,double radius)
	  {
	 super(x1,y1);
	 this.radius=radius;
	  }
	 public void show()
	 {
	 System.out.println("Circle point and radius:");
	 System.out.println(super.toString()+"\n Radius of a Circle:"
	 +radius);
	 
	 }

}
