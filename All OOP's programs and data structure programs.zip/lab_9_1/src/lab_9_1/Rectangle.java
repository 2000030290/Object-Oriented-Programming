package lab_9_1;

public class Rectangle  extends Point{
	 protected double x2,y2;
	  Rectangle(double x1,double y1,double x2,double y2)
	  {
	 super(x1,y1);
	 this.x2=x2;
	 this.y2=y2;
	  }
	  public void show()
	  {
	 System.out.println("Rectangle diagonal Coordinates:");
	 System.out.println(super.toString()+"\n X2-Coordinate:"+x2+
	  "\nY2-Coordinates:"+y2);
	  }
	}


