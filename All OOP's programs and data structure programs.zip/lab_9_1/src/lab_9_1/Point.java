package lab_9_1;

public  abstract class Point {
	 protected double x1;
	  protected double y1;
	  Point(double x1,double y1)
	  {
	 this.x1=x1;
	 this.y1=y1;
	  }
	  abstract void show();
	  public void move()
	  {
	 this.x1+=x1;
	 this.y1+=y1;
	  }
	  public String toString()
	  {
	 return "X1-coorinate:"+x1+"\nY1-coordinate:"+y1;
	  }
	}


