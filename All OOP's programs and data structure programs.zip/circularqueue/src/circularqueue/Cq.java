package circularqueue;

public class Cq <T> {

	T arr[];
	int front ,rear;
	int size;
	public Cq(int size)
	{
		this.size=size;
		front =-1;
		rear=-1;
		arr=(T[])new Object [size];
	}
	public boolean isEmpty()
	{
		if(front==-1 && rear==-1)
			return true;
		else
			return false;
	}
	public boolean isFull()
	{
		if(rear==size-1 ||rear+1==front)
			return true;
			else
		    return false;
	}
	public void enqueue(T data)
	{
		if(isFull())
		System.out.println("Queue is overflown");
		else
		if(front==-1)
		front++;
		rear=(rear+1)%size;
		arr[rear]=data;
	}
	public void dequeue()
	{
		if(isEmpty())
		System.out.println("Queue is underflown");
		else
		{
			System.out.println(arr[front]+"is delected");
			if(front==rear)
			{
				front=rear=-1;
			}
			else
			front=(front+1)%size;
		}
	}
		public void display()
		{
			if(isEmpty())
			
				System.out.println("Queue is underflown");
				else
				{
					int i=front;
					while(i!=rear)
					{
						System.out.println(arr[i]);	
						i=(i+1%size);
					}
			
			
			
			}
	
			}
		
}


