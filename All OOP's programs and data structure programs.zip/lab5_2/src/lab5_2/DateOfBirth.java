package lab5_2;
import java.util.Scanner;
import java.util.StringTokenizer;
public class DateOfBirth {

	public static void main(String[] args) {
	
    Scanner sc=new Scanner(System.in);
    for(int i=0;i<10;i++)
    {
    String dob=sc.next();
    StringTokenizer st=new StringTokenizer(dob,"-");
    int d=Integer.parseInt(st.nextToken());
    if(d==11||d==12||d==13)
    {
    	System.out.print(d+"th");
    	
    }
    else if(d%10==1)
    {
    	System.out.print(d+"st");
    }
    		
    else if(d%2==2)
    {
    	System.out.print(d+"nd");
    }
    else if(d%10==3)
    {
    	System.out.print(d+"th");
    }
    else 
    	System.out.print(d+"th");
    int m=Integer.parseInt(st.nextToken());
    switch(m)
    {
    case 1:
    	System.out.print("January");
    	break;
    case 2:
    	System.out.print("february");
    	break;
    case 3:
    	System.out.print("march");
    	break;
    case 4:
    	System.out.print("april");
    	break;
    case 5:
    	System.out.print("may");
    	break;
    case 6:
    	System.out.print("june");
    	break;
    case 7:
    	System.out.print("july");
    	break;
    case 8:
    	System.out.print("augest");
    	break;
    case 9:
    	System.out.print("september");
    	break;
    case 10:
    	System.out.print("october");
    	break;
    case 11:
    	System.out.print("november");
    	break;
    case 12:
    	System.out.print("december");
    	break;
    	default:
        System.out.print("invalid input");
    	break;
}
    int y=Integer.parseInt(st.nextToken());
    System.out.print("-"+y);
	
    }
}
}
