package labexam;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Sample_ {

	public static void main(String[] args) throws Exception{
		File f=new File("C:\\Users\\DELL\\eclipse-workspace\\labexam\\src\\labexam\\Data.txt");
		Scanner sc=new Scanner(f);
		int lines=0;
		int totalWords=0;
		while(sc.hasNext())
		{
		String s=sc.nextLine();
		int count=0;
		for(int i=0;i<s.length();i++)
		{
		if(s.charAt(i)==' ')
		count++;
		}
		lines++;
		totalWords+=count+1;
		System.out.println(lines+"\t"+(count+1)+"\t"+s);
		}
		System.out.println("Total Count of Words:"+totalWords);
		}
		

	}


