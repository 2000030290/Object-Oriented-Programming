package SingleLinkedList;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		   Node sList = new Node();        
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter the data in the single linked list");
	        sList.addNode(sc.nextInt());    
	        sList.addNode(sc.nextInt());    
	        sList.addNode(sc.nextInt());    
	        sList.addNode(sc.nextInt());    
	            
	         
	        sList.display();    
	    }    

	}


