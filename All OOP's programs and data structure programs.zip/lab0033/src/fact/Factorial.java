package fact;
import java.util.Scanner;
import lab0033.Demo;
public class Factorial {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		System.out.println(Demo.factorial(a));
		}
		

	}


