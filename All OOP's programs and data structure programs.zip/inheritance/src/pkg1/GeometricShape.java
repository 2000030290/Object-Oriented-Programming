package pkg1;

public class GeometricShape {
	protected String boarderColor;
	protected boolean fill;

}
