package pkg2;
import pkg2.Rectangle;
public class Demo {

	public static void main(String[] args) {
		Rectangle r=new Rectangle();
		System.out.println(Rectangle.display());
	}

}
