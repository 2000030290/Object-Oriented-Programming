package pkg2;
import pkg1.GeometricShape;
public class Rectangle extends GeometricShape {
	private double length,breadth;
	public void display()
	{
		System.out.println(length);
		System.out.println(breadth);
		System.out.println(boarderColor);
		System.out.println(fill);
	}
	

}
