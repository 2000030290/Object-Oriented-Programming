package Test;

public class LbPractices {
	public static int factorial(int n)
	{
		int f=1;
	}

	public static void main(String[] args) {
		
	    

	}

}
 