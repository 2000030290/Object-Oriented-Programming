package labfact;

public class Factorial {

	public static void main(String[] args) {
		{
			System.out.println(Demo.factorial(5));
			}	
		

	}

}
