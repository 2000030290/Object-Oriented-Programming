package Linearprobing;

public class LinearProbing {
	 int a[],size;
	 public LinearProbing(int size)
	 {
		 this.size=size;
		 a=new int[size];
		 for(int i=1;i<size;i++)
		 {
			 a[i]=-1;
		 }
	 }
	 public void insert(int key)
	 {
		 int index=key%size;
		 if(a[index]==-1) 
			a[index]=key; 
		 
		 else
		 {
			 for(int i=1;i<size;i++)
			 {
				 int nindex=(index+i)%size;
				 
					 if(a[nindex]==-1)
					 {
						 a[nindex]=key;
						 break;
					 }
				 
				 
			 }
		 }
	 }
	 public void display()
	 {
		 for(int i=1;i<size;i++)
		 {
			 System.out.println(a[i]+"is"+i+"index");
		 }
	 }
	 public void search(int key)
	 {
		 int index=key%size;
		 if(a[index]==key)
		 {
			 System.out.println(key+"is found at"+index);
		 }
		 else
		 {
			 for(int i=0;i<size;i++) {
				 int nindex=(index+i)%size;
				 if(a[nindex]==key)
				 {
					 System.out.println(key+"is found at"+nindex);
					 break;
				 }
			 }
		 }
	 }
	 

}
