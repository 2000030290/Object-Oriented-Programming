package Linearprobing;
import java.util.Scanner;
public class Main {
    static Scanner sc=new Scanner(System.in);
    static LinearProbing l=new  LinearProbing(10);
	public static void main(String[] args) {
		boolean repeat=true;
		int ch;
		while(repeat)
		{
			System.out.println("***MENU***");
			System.out.println("1.Insert an element");
			System.out.println("2.Display elements");
			System.out.println("3.Search an element");
			System.out.println("4.EXIT");
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1: l.insert(sc.nextInt());
			        break;
			case 2: l.display();
			        break;
			case 3: l.search(sc.nextInt());
			        break;
			case 4: repeat=false;
			        break;
			 default: System.out.println("INVALID CHOICE");
			}
		}
		
	}

}
