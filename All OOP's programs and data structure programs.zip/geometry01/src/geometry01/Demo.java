package geometry01;

public class Demo {
	private double length,breadth,height;
	public double volume() {
		return length*breadth*height;
	}
	public Demo()
	{
		length=breadth=height=1;
	}

}
