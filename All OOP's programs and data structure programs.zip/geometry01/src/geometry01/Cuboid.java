package geometry01;

public class Cuboid {

	public static void main(String[] args) {
		Demo c=new Demo();
        System.out.println(c.volume());
	}

}
