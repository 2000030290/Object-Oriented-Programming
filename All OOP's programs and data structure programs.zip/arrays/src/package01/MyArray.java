package package01;
import  java.util.Scanner;
public class MyArray {

	
		// TODO Auto-generated method stub

		//this program works on an integer array and performs various operations on the array
		//static members
		private static final int MAX_CAPACITY=10;
		private static int[] a = new int[MAX_CAPACITY];
		private static int count;
		private static Scanner sc = new Scanner(System.in);

		public static void main (String[] args) {	
			
			boolean repeat = true;
			int choice;
			
			while(repeat) {
				choice = selectMenu();
				switch(choice) {
				case 1:
				{
					System.out.println("Enter the value of an element to be inserted into the array");
					int element = sc.nextInt();
					boolean result = addElementEnd(element);
					System.out.println(result?"Element "+element+" added successfully":"Cannot add element as the array is full");
				}
					break;
				case 2:
				{
					printArrayElements();
				}
					break;
				case 3:
				{
					System.out.println("Enter an element to be searched");
					int element = sc.nextInt();
					int result = searchElement(element);
					System.out.println((result==-1)?"Element cannot be found in the array":"Element found at index = "+result);
				}
					break;
				case 4:
				{
					System.out.println("Enter the elemet to be removed");
					int element = sc.nextInt();
					int result = deleteElement(element);
					System.out.println((result==-1)?"Element NOT found":"Element deleted successfully");
				}
					break;
				case 5:
					{
						int result = minElement();
						System.out.println((result==-1000)?"Cannot find min element":"The min element in the array = "+result);
					}
					break;
				case 6:
				{
					int result = maxElement();
					System.out.println((result==9999)?"Cannot find max element":"The max element in the array = "+result);
				}
					break;
				case 7:
				{
					arraySort();
					System.out.println("Array successfulyl sorted. Print the element to verify");
				}
					break;
				case 8:
				{
					System.out.println("Which element do you wish to update");
					int element = sc.nextInt();
					System.out.println("What should the updated value be?");
					int upElement = sc.nextInt();
					int result = updateElement(element, upElement);
					System.out.println((result==0)?"Cannot find the element":"Element Updated Successfully");
					
				}
					break;
				default:repeat = false;
					
				}
						
			}
			System.out.println("Thank you! Have a good day!");
			

		}
		
		private static int selectMenu() {
			System.out.println("what operations to be performed?");
			System.out.println("1. add an element into the array-insert at the end");
			System.out.println("2. print array elements - traverse");
			System.out.println("3. search array element-search");
			System.out.println("4. remove an array element-delete");
			System.out.println("5. min element in the array-min");
			System.out.println("6. max element in the array-max");
			System.out.println("7. sort the elements of the array-sort");
			System.out.println("8. update an element-update");
			System.out.println("Enter any other number to exit");
			return sc.nextInt();
		}
		
		private static boolean addElementEnd(int x) {
			if(count<MAX_CAPACITY) {
				a[count++]=x;
				return true;
			}
			return false;
		}
		
		private static void printArrayElements() {
			if (count==0) System.out.println("No elements to be printed");
			for (int i=0; i<count; i++) {
				System.out.print(a[i]+" ");
			}
			System.out.println();
			System.out.println("Total elements in the array = "+count);
		}
		
		private static int searchElement(int x) {
			//returns the latest matching index
			System.out.println("Enter 1 for earliest matching index and any other value for latest matching index");
			int match = sc.nextInt();
			if (match==1) {
				for(int i=0;i<count;i++) {
					if (x==a[i]) return i;
				}
				return -1;
					
			}
			else {
				int result = -1;
				for(int i=0;i<count;i++) {
					if (x==a[i]) result=i;
				}
				return result;
			}
			
			
		}
		
		private static int deleteElement(int x) {
			int result = searchElement(x);
			if(result==-1) return result;
			
			if(result!=count-1) {//not the last element to be removed {
				for(int i = result; i<count ; i++) {
					a[i]=a[i+1];
				}
			}
		count--;
		return result;	
		}
		
		private static int minElement() {
			if (count==0) return -1000;//no elements in array
			int min = a[0];
			for(int i=1;i<count;i++) {
				if(a[i]<min) min=a[i];
			}
			return min;
		}
		
		private static int maxElement() {
			if (count==0) return 9999;//no elements in array
			int max = a[0];
			for(int i=1; i<count;i++) {
				if (a[i]>max) max = a[i];
			}
			return max;
		}
		
		private static void arraySort() {
			//selection sort technique
			for (int i=0; i<count-1; i++) {
				int minInd = i;
				for (int j=i+1; j<count; j++) {
					
					if(a[j]<a[minInd]) minInd=j;
				}
				if(minInd!=i) {
					int temp = a[i];
					a[i]=a[minInd];
					a[minInd]=temp;
				}
			}
		}
		
		private static int updateElement(int x, int y) {
			int change = 0;
			for (int i=0; i<count; i++) {
				if (a[i]==x) {
					a[i]=y;
					change++;
				}
			}
			System.out.println("Value updated at "+change+" indices");
			return change;
		}

	}