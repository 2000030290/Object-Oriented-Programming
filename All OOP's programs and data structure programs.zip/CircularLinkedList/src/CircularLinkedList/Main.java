package CircularLinkedList;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
	
		    Node n=new Node(10);
		    Scanner sc = new Scanner(System.in);
		    boolean cont=true;
		    int ch;
		    while(cont)
		    {
		      System.out.println("Menu\n1.InsertAtBegin\n2.InsertAtEnd\n3.DeleteAtBegin\n4.Display\n5.Exit");
		      ch=sc.nextInt();
		      switch(ch)
		      {
		      case 1: System.out.println("Enter element to insert: ");
		      int x = sc.nextInt();
		      n.insertAtBegin(x);
		      break;
		      case 2: System.out.println("Enter element to insert: ");
		      int y = sc.nextInt();
		      n.insertAtEnd(y);
		      break;
		      case 3: n.deleteAtBeg();
		      break;
		      case 4: n.display();
		      break;
		      case 5: cont=false;
		      break;
		      }
		    }
		  
	}

}
