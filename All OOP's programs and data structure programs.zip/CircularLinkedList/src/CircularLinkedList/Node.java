package CircularLinkedList;

public class Node {

	  int data;
	  Node pre,next;
	  Node(int x)
	  {
	    data=x;
	    next=null;
	  }
	  Node head=null;
	  public void insertAtBegin(int x)
	  {
	    Node newnode=new Node(x);
	    if(head==null)
	    {
	      head=newnode;
	      newnode.next=head;
	    }
	    else
	    {
	      Node temp=head.next;
	      while(temp.next!=head)
	      {
	        temp=temp.next;
	      }
	      newnode.next=head;
	      temp.next=newnode;
	      head=newnode;
	    }
	  }
	  public void insertAtEnd(int x)
	  {
	    Node newnode=new Node(x);
	    if(head==null)
	    {
	      head=newnode;
	      newnode.next=head;
	    }
	    else
	    {
	      Node temp = head.next;
	      while(temp.next!=head)
	      {
	        temp=temp.next;
	      }
	      temp.next=newnode;
	      newnode.next=head;
	    }
	  }
	  public void deleteAtBeg()
	  {
	    if(head==null)
	    {
	      System.out.println("No Elements");
	    }
	    else
	    {
	      Node temp=head.next;
	      while(temp.next!=head)
	      {
	        temp=temp.next;
	      }
	      head=head.next;
	      temp.next=head;
	    }
	  }
	  public void deleteAtEnd()
	  {
	    if(head==null)
	    {
	      System.out.println("No elements to delete");
	    }
	    else
	    {
	      Node temp=head.next;
	      Node temp1=null;
	      while(temp.next!=head)
	      {
	        temp1=temp;
	        temp=temp.next;
	      }
	      temp1.next=head;
	    }
	  }
	  public void display()
	  {
	    if(head==null)
	    {
	      System.out.println("no elements");
	    }
	    else
	    {
	      Node temp=head.next;
	      System.out.print(head.data+"->");
	      while(temp!=head)
	      {
	        System.out.print(temp.data+"->");
	        temp=temp.next;
	      }
	    }
	  }
}
