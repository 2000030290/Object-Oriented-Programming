package package01;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;
public class fileCopy {

	public static void main(String[] args) throws Exception
	{
		int a,b,c;
		File f1=new File("C:\\Users\\DELL\\eclipse-workspace\\files\\src\\package01\\input.txt");
        File f2=new File("C:\\Users\\DELL\\eclipse-workspace\\files\\src\\package01\\output.txt");
        Scanner Sc = new Scanner(f1);
        a=Sc.nextInt();
        b=Sc.nextInt();
        c=a+b;
        PrintWriter pw=new PrintWriter(f2);
        pw.write("the sum is" +c);
        pw.close();
        Sc.close();
        
	}

}
