package calender;
import java.util.Scanner;
import java.util.Calendar;
public class Calendarinfo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter student id");
		long id=sc.nextLong();
		System.out.println("enter student name");
		String name=sc.next();
		System.out.println("enter student gender");
		char gender =sc.next().charAt(0);
		System.out.println("enter date");
		int d=sc.nextInt();
		System.out.println("enter month");
		int m=sc.nextInt();
		System.out.println("enter year");
        int y=sc.nextInt();
        System.out.println("enter marks of 6 students");
        int marks[]=new int [6];
        for(int i=0;i<=5;i++)
        	marks[i]=sc.nextInt();
        Calendar c=Calendar.getInstance();
        c.set(y,m,d);
        Demo s=new Demo(id,name,gender,c,marks);
        System.out.println(s);
        
        
        
	}

}
