package calender;
import java.util.Calendar;
public class Demo {
	private long id;
	private String name;
	private char gender;
    private Calendar dob;
    private int marks[];
    public Demo (long id,String name,char gender,Calendar dob,int marks[])
    {
    	this.id=id;
    	this.name=name;
    	this.gender=gender;
    	this.dob=dob;
    	this.marks=marks;
    }
    public String toString()
    {
    String s;
    s="ID:"+id;
    s=s+"\n name"+name;
    s=s+"\n gender"+gender;
    s=s+"\n dob"+dob.get(Calendar.DATE)+"-"+dob.get(Calendar.MONTH)+"-"+dob.get(Calendar.YEAR);
    s=s+"\nMarks:";
    String m=" ";
    for(int i=0;i<6;i++)
    	m=m+marks[i]+",";
    	s=s+m;
    return s;
}
}
