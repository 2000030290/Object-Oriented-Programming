package Quadraticprobing;

public class QuadraticProbing {

     int a[],size;
     public QuadraticProbing(int size)
     {
    	 this.size=size;
    	 a=new int[size];
    	 for(int i=1;i<size;i++)
    	 {
    		 a[i]=-1;
    	 }
    	 
     }
    public void insert(int key)
    {
    	int index=key%size;
    	if(a[index]==-1)
    		a[index]=key;
    	else
    	{
    		for(int i=1;i<size;i++)
    		{
    	
    			int nindex=(key+i*i)%size;    		
    			if(a[nindex]==-1)
    			{
    			
    			a[nindex]=key;
    			break;
    		}
    	}
    }
    }
    public void display()
    {
    	for(int i=0;i<size;i++)
    		System.out.println(a[i]+"is at"+i+"index");
    }
    public void search(int key)
    {
    	int index=key%size;
    	if(a[index]==key)
    		System.out.println(key+"is at"+index);
    	else
    	{
    		for(int i=0;i<size;i++)
    		{
    		int nindex=(key+i*i)%size;
    		if(a[nindex]==key)
    		{
    			System.out.println(key+"is found at"+nindex);
    			break;
    		}
    }
    }
}
}
