package binarysearchtree;

public class TreeOperations {
		TNode root=null;
		 public void inorder(TNode root)
		 {
		  if(root!=null)
		  {
		   inorder(root.left);
		   System.out.println(root.data);
		   inorder(root.right);
		  }
		 }
		 public void preorder(TNode root)
		 {
		  if(root!=null)
		  {
		   System.out.println(root.data);
		   preorder(root.left);
		   preorder(root.right);
		  }
		 }
		 public void postorder(TNode root)
		 {
		  if(root!=null)
		  {
		   postorder(root.left);
		   postorder(root.right);
		   System.out.println(root.data);
		  }
		 }
		 public int minimum(TNode root)
		 {
		  while(root.left!=null)
		   root=root.left;
		  return root.data;
		 }
		 public int maximum(TNode root)
		 {
		  while(root.right!=null)
		   root=root.right;
		  return root.data;
		 }
		 public void search(TNode root,int key)
		 {
		  if(root!=null)
		  {
		   if(key==root.data)
		   {
		    System.out.println("found");
		   }
		   else if(key<root.data)
		   {
		    search(root.left,key);
		   }
		   else  {
		    search(root.right,key);
		   }
		  }
		   else 
		    System.out.println("Not Found");
		  }
		 public TNode insert(TNode root,int data)
		 {
		  if(root==null)
		  {
		   TNode r=new TNode(data);
		   return r;
		  }
		  else if(data<root.data)
		  {
		   root.left=insert(root.left,data);
		  }
		  else {
		   root.right=insert(root.right,data);
		  }
		  return root;
		 }
		 }