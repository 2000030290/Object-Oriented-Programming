package binarysearchtree;


public class TNode {
	TNode left;
	int data;
	TNode right;
	public TNode(int Data)
	{
		this.data=data;
		left=right=null;
	}

}



