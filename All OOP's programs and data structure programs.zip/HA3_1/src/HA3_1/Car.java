package HA3_1;

public class Car extends Vechicle {
	private int doors;

	public Car(String registrationnumber,String ownername,int doors) {
		super(registrationnumber, ownername);
		this.doors=doors;
		
	}
	public String toString()
	{
		String s;
		s=super.toString();
		s=s+"\n Number  of Doors="+doors;
		return s;
	}


	
}
