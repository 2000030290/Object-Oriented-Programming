package HA3_1;

public class Demo {

	public static void main(String[] args) {
	
	Car c=new Car("AP31 4545","akhil", 4);
	System.out.println(c);
	Truck t=new Truck("AP31 6767","pavan",6);
	System.out.println(t);
    }

}
