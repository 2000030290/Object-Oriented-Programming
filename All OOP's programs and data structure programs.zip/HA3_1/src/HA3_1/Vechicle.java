package HA3_1;

public class Vechicle {
	 private String registrationnumber;
	private String ownername;
	public Vechicle(String registrationnumber,String ownername)
	{
		this.registrationnumber=registrationnumber;
		this.ownername=ownername;
	}
	
	  public String getRegistrationnumber()
	  {
		  return registrationnumber;
	  }
	  
	  public String getOwnername()
	  {
		  return ownername;
	  }
		public String toString()
		{
			String s;
			s="Registration number="+registrationnumber;
			s=s+"\nOwnername="+ownername;
			return s;
		}
     
}
