package HA3_1;

public class Truck  extends Vechicle{
	private int axle;

	public Truck(String registrationnumber, String ownername,int axle) {
		super(registrationnumber, ownername);
		this.axle=axle;
		
	}
	
	public String toString()
	{
		String s;
		s=super.toString();
		s=s+"\nNumber of Axles="+axle;
		return s;
	}

}
