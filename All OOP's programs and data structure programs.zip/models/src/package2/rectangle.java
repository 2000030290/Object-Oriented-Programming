	package package2;

public class rectangle {
	//instance members
		public double length, breadth;
		private String color;
		
		//instance methods
		private double calcArea() {
			
			return this.length*this.breadth;
		}
		
		private double calcPeri() {
			return 2*(this.length+this.breadth);
		}
		
		public String display() {
			String res;
			res ="Area of rectangle"+calcArea();
			res=res+"Perimeter of rectangle"+calcPeri();
			return res;
		}
}
