package package2;

public class Circle {
	//members
		public double radius;
		public String color;
		
		
		//a class can have static members and instance members
		//a class can also have static methods and instance methods
			
		//static method cannot have instance members in it; it can only have static members or specific object members in it
		//default constructor is never defined by the coder
		
		
		
		private double calcArea() {
			double result = Math.PI*this.radius*this.radius;
			
			return result;
		}
		
		private double calcPeri() {
			double result = Math.PI*2*this.radius;
			return result;
		}
		
		public String display() {
			String res;
			res ="Area of circle"+calcArea();
			res=res+"Perimeter of circle"+calcPeri();
			return res;
		}

	}


