package package1;
import package2.*;
public class enduser {

	public static void main(String[] args) {
int x = 10;
		
		boolean isCircle = true;
		
		if (isCircle) {
			
			Circle c1 = new Circle();//special method called as a constructor which has the same name as the class and doesnt return anything
			c1.radius = 10;
			c1.color = "Yellow";
			System.out.println(c1.display());
			
			Circle c2;
			c2 = new Circle();
			c2.radius = 20;
			c2.color = "Red";
			System.out.println(c2.display());
					
		}
		else {
			rectangle r1 = new rectangle();
			r1.length=10;
			r1.breadth=20;
			System.out.println(r1.display());
			
			
		}
	}

}
