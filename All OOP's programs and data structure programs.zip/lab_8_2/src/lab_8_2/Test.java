package lab_8_2;
import java.util.Calendar;
import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter hiring date, month, year");
		int d=sc.nextInt();
		int m=sc.nextInt();
		int y=sc.nextInt();
		Calendar ca=Calendar.getInstance();
		ca.set(y, m, d);
		System.out.println("Address:");
		String s=sc.next();
		String ci=sc.next();
		String st=sc.next();
		int pi=sc.nextInt();
		Address ad=new Address(s,ci,st,pi);
		System.out.println("Enter name, mobile , email, Salary");
	    Employee e=new Employee(sc.next(),ad,sc.nextLong(),sc.next(),sc.nextInt(),ca);
	    System.out.println(e.toString());
	    
	    System.out.println("enter address");
	    String s1="auto",ci1="vij",st1="AP";
	    int pi1=520010;
	    Address ad1=new Address(s1,ci1,st1,pi1);
	    System.out.println("Enter name, mobile, email, cgpa");
	    Person p=new Student(sc.next(),ad1,sc.nextLong(),sc.next(),sc.nextDouble());
	    System.out.println(p);

	
	  
	}

}
