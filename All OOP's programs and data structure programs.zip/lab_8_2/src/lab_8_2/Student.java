package lab_8_2;

public class Student extends Person{
	private double cgpa;
	public Student(String name, Address a, long mobile, String email,double cgpa) {
		super(name, a, mobile, email);
		this.cgpa=cgpa;
	}
	
	public String toString() {
		String s=super.toString();
		s=s+"  CGPA- "+cgpa;
		return s;
	}

}
