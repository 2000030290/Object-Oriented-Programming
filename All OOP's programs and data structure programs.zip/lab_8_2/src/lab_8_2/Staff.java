package lab_8_2;
import java.util.Calendar;
public class Staff extends Employee{
	private int hoursWorked;
	public Staff(String name, Address a, long mobile, String email, int salary,Calendar date,int hoursWorked) {
		super(name, a, mobile, email, salary,date);
		this.hoursWorked=hoursWorked;
	}
	public String toString() {
		String s=super.toString()+"  Hours worked-"+hoursWorked;
		return s;
	}

}
