package lab_8_2;

public class Person {
	private String name;
	private Address a;
	private long mobile;
	private String email;
	
	public Person(String name,Address a,long mobile,String email) {
		this.name=name;
		this.a=a;
		this.mobile=mobile;
		this.email=email;
	}
	
	public String toString() {
		String s="Name- "+name+"\nAddress: "+a.toString()+"\nMobile no: "+mobile+" Email: "+email;
		return s;
	}

}
