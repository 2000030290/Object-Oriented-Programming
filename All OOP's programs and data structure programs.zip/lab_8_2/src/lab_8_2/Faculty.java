package lab_8_2;

import java.util.Calendar;

public class Faculty extends Employee{
	private String designation;
	public Faculty(String name, Address a, long mobile, String email, int salary,Calendar date,String designation) {
		super(name, a, mobile, email, salary,date);
		this.designation=designation;
	}
	public String toString() {
		String s=super.toString()+"  designation- "+designation;
		return s;
		
	}

}
