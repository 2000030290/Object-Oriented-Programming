package lab_8_2;

import java.util.Calendar;

public class Employee extends Person{
	private int salary;
	private Calendar dateHired;
	
	
	public Employee(String name,Address a,long mobile,String email,int salary,Calendar date) {
		super(name,a,mobile,email);
		this.salary=salary;
		this.dateHired=date;
		
	}
	
	public String toString() {
		String s;
		s=super.toString()+"  salary: "+salary+"  Date hired:- "+dateHired.get(Calendar.DATE)+
				"-"+dateHired.get(Calendar.MONTH)+"-"+dateHired.get(Calendar.YEAR);
		
		return s;
	}

}
