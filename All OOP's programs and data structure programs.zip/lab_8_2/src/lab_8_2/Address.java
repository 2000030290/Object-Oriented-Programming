package lab_8_2;

public class Address {
	public String street,city,state;
	public int pinCode;
	  public String toString(){
	    String s="  Street-"+street+"  City-"+city+"  State-"+state+"  PinCode-"+pinCode;
	    return s;
	  }
	  public Address(String street,String city,String state,int pinCode) {
		  this.street=street;
		  this.city=city;
		  this.state=state;
		  this.pinCode=pinCode;
	  }

}
