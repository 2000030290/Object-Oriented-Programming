package Area;

public class Area {
	private int L;
	private int B;
	public Area(int L,int B)
	{
		this.L=L;
		this.B=B;
	}
	public double areaOfTriangle(int x,int y)
	{
		int Area=(L*B)/2;
		return Area;
		
	}
	public String toString()
	{
		String s;
		s="Length="+L;
	    s=s+"Breadth="+B;
	    s=s+"Area of the triangle="+areaOfTriangle(L, B);
	    return s;
		
		
	}

}
