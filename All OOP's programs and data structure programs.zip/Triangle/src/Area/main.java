package Area;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	Area a=new Area(sc.nextInt(),sc.nextInt());
     System.out.println("Area of the triangle is="+a);
	}

}
