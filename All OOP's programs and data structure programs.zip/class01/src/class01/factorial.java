package class01;

public class factorial {

	public static void main(String[] args) {
	int n=5;
	int result;
	result=factorial(n);
	System.out.print("factorial value is ="+result);

	}
	public static int factorial(int x) {
		int value=1;
	for(int i=1;i<=x;i++)
	{ 
		value=value*i;
	}
	return value;
	}

}
