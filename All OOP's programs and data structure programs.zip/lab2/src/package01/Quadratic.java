package package01;
import java.util.Scanner;
public class Quadratic {

	public static void main(String[] args) {
		
			  Scanner sc=new Scanner(System.in);
			  Equation ob=new Equation();
			  System.out.println("Enter a:");
			  ob.a=sc.nextInt();
			  System.out.println("Enter b:");
			  ob.b=sc.nextInt();
			  System.out.println("Enter c:");
			  ob.c=sc.nextInt();
			  
			  System.out.println(ob);
	  
	}

}

		