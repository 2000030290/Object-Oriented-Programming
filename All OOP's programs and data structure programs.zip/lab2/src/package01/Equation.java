package package01;

public class Equation {
	public int a;
	 public int b;
	 public int c;
	 public double r1;
	 public double r2;
	 public void Attri(int a,int b,int c) {
	  this.a=a;
	  this.b=b;
	  this.c=c;
	 }
	 public int geta() {
	  return a;
	 }
	 public int getb() {
	  return b;
	 }
	 public int getc() {
	  return c;
	 }
	 public double getRoot1() {
	  return -b+Math.sqrt(b*b-4*a*c)/2*a;
	 }
	 public double getRoot2() {
	  return -b-Math.sqrt(b*b-4*a*c)/2*a;
	 }
	 public String toString()
	 {
	  String S;
	  S="a:"+a+"\n"+"b:"+b+"\n"+"c:"+c+"\n"+"r1:"+getRoot1()+"\n"+"r2:"+getRoot2()+"\n";
	  return S;
	 }


}
