package lab004;

public class Accountdetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
