package lab004;

public class BankDetails {
	private long id;
	private long balance;
	public 	void setid(long id)
	{
		this.id=id;
	}
	public void setbalance(long balance) {
		this.balance=balance;
	}
	public long
}
