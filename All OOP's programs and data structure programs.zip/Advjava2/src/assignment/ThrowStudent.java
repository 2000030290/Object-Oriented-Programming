package assignment;

public class ThrowStudent extends Student {
	 public void setpercentage(double percentage) throws InvalidResultException
     {
     	if(percentage>=35)
     	{
     		this.percentage=percentage;
     	}
     	else
     	{
     		throw new InvalidResultException();
     	}
     	
     }
        

}
