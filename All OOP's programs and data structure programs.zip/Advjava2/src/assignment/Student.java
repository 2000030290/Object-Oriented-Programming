package assignment;
import java.util.*;

public class Student
{
   Scanner sc=new Scanner(System.in);
   int RegNo,Total=0,subjects;
   double percentage;
   String name;
   int marks[];
   Student()
   {
      System.out.print("Enter Registration No.: ");
      RegNo=sc.nextInt();
      System.out.print("Enter Student Name: ");
      name=sc.next();;
      getDisMarks();
   }
   public void getDisMarks()
   {
       marks=new int[5];
       System.out.print("Enter marks of Java: ");
       marks[0]=sc.nextInt();
       System.out.print("Enter marks of Python: ");
       marks[1]=sc.nextInt();
       System.out.print("Enter marks of Maths: ");
       marks[2]=sc.nextInt();
       System.out.print("Enter marks of operating system: ");
       marks[3]=sc.nextInt();
       System.out.print("Enter mathematical programming-1: ");
       marks[4]=sc.nextInt();
       for(int i=0;i<5;i++)
       {
          Total+=marks[i];
          percentage=Total/5;
       }
       System.out.println("Total Marks of student "+name+": " +Total);
	   System.out.println("Percentage of student"+name+":"+percentage);
  
   } 
}