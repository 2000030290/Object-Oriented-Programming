package assignment;

public class InvalidResultException extends Exception{
	public String toString()
	{
		return "Invalid Result exception";
	
	}

}
