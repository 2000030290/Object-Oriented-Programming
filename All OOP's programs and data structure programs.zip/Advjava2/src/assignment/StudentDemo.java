package assignment;

public class StudentDemo {

	public static void main(String[] args) {
		try {
			 Student s[]=new Student[25];
		        for(int i=0;i<25;i++)
		              s[i]=new Student();
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

}
