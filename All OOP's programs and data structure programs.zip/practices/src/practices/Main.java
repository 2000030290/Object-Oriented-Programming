package practices;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Labs l=new Labs(30290,1000.0);
		Scanner sc=new Scanner(System.in);
		 System.out.println(l);
		 System.out.println("enter amount to withdraw");
		 l.withdraw(sc.nextInt());
		 System.out.println(l);
		 System.out.println("enter amount to deposit");
		 l.deposit(sc.nextDouble());
		 System.out.println(l);
		 sc.close();
	


	}

}
