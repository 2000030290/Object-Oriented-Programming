package practices;

public class Labs {
   private int id;
   private double balance;
   public Labs()
   {
	   this.id=0;
	   this.balance=0;
   }
   public Labs(int id,double balance)
   {
	   this.id=id;
	   this.balance=balance;
   }
   public int getid()
   {
	   return id;
   }
   public boolean setid(int id)
   {
	   if(id>0)
	   {
		   this.id=id;
	   return true;
	   }
	   else
	   {
		   this.id=0;
	   return false;
	   }
   }
	  public boolean setbalance(double balance)
	   {
		   if(balance>0)
		   {
			   this.balance=balance;
			   return true;
			   
		   }
		   else
		   {
			   this.balance=0;
			   return false;
		   }   
   }
	  public String toString()
	  {
		  String s;
		  s="ID="+id;
		  s=s+"\n balance="+balance;
		  return s;
	  }
	  public void withdraw(double amt)
	  {
		  if(amt<=balance)
		  {
			  System.out.println("Withdraw successful");
			  this.balance=this.balance-amt;
		  }
		  else
		  {
			  System.out.println("insufficient balance");
			  
		  }
		  
	  }
	  public void deposit(double amt)
	  {
		  if(amt>=0)
		  {
		  System.out.println("Deposit successful");
		  this.balance=this.balance+amt;
		  
		  
	  }
		  else
		  {
			  System.out.println("invalid amount");
		  }
	  

}
}
