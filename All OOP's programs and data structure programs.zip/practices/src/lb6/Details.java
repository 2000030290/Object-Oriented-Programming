package lb6;

public class Details {
      private long id;
      private String name;
      private String dept;
      public Details()
      {
    	  this.id=0;
    	  this.name="#";
    	  this.dept="#";
      }
      public Details(long id,String name,String dept)
      {
    	  this.id=id;
    	  this.name=name;
    	  this.dept=dept;
    	  
      }
      public long getid()
      {
    	  return id;
      }
      public String getname()
      {
    	  return name;
      }
      public String getdept()
      {
    	  return dept;
      }
      public void setname( String name)
      {
    	  this.name=name;
      }
      public String toString()
      {
    	  String s;
    	  s="ID="+id;
    	  s=s+"\n Name="+name;
    	  s=s+"\n department="+dept;
    	  return s;
      }
}
