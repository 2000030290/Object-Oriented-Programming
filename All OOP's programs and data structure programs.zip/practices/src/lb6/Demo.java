package lb6;
import java.util.Scanner;
public class Demo {
	private static Details D[]=new Details[10];
	private static int count=0;
	private static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		boolean repeat=true;
		int choice;
		while(repeat)
		{
			System.out.println("*****MENU*****");
			System.out.println("1.new employee details");
		    System.out.println("2.update name based on id");
		    System.out.println("3.all employee data");
			System.out.println("4.print employee of specific department");
		    System.out.println("5.exit");
			System.out.println("enter your choice");
			
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:add();
				break;
			case 2:update();
			break;
			case 3:print();
			break;
			case 4:printdept();
			break;
			case 5:repeat=false;
			break;
			default : System.out.println("invalid input");
			}
		}
	}
	

	private static void add() {
		System.out.println("Enter Employee ID, Name and Department");
		D[count]=new Details(sc.nextLong(),sc.next(),sc.next());
		count++;
		
	}
private static void update() {
	for(int i=1;i<=10;i++)
		System.out.println(D[i]);
	
		
	}
private static void print() {
	System.out.println("Enter department");
	String d=sc.next();
	for(int i=0;i<count;i++)
	{
	if(D[i].getdept().equals(d))
	System.out.println(D[i]);
	}
	
	
}
private static void printdept() {
	
	System.out.println("Enter ID of Employee");
	long id=sc.nextLong();
	int index=-1;
	for(int i=0;i<count;i++)
	{
	if(D[i].getid()==id)
	{
	index=i;
	break;
	}
	}
	if(index==-1)
	{
	System.out.println("No such ID exists");
	}
	else
	{
	System.out.println("Enter new name of Employee");
	String n=sc.next();
	D[index].setname(n);
	}
}
}
