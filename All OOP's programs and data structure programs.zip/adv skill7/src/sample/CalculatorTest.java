package sample;
import java.util.Scanner;

import static org.junit.Assert.*; 

import org.junit.Test;
public class CalculatorTest {
  @Test 
   public void testAdd() { 
          Calculator c=new Calculator();   
    int a =10,b=10,actual=c.add(a, b),expected=20; 
    assertEquals(actual, expected); 
   } 
   
   @Test 
   public void testsubtract() { 
   Calculator c=new Calculator(); 
   int a =10,b=5,actual=c.subtractor(a, b),expected=5; 
   assertEquals(actual, expected); 
   } 
   @Test 
   public void testmultiply() { 
   Calculator c=new Calculator(); 
   int a =10,b=5,actual=c.multiply(a, b),expected=50; 
   assertEquals(actual, expected); 
   } 
   @Test 
   public void testdivision() { 
   Calculator c=new Calculator(); 
   int a =10,b=5,actual=c.division(a, b),expected=2; 
   assertEquals(actual, expected); 
   } 
   
   

}


