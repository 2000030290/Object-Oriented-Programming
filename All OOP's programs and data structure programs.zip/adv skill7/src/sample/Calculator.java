package sample;

public class Calculator {
	  public int add(int a,int b) {
		    return a+b;
		  }
		public int subtractor(int a,int b) {
		  return a-b;
		}
		public int multiply(int a,int b) {
		  return a*b;
		}
		public int division(int a,int b) {
		  return a/b;
		}

}
