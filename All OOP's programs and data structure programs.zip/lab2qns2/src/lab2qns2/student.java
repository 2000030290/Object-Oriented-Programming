package lab2qns2;

public class student {

	public static void main(String[] args) {
		Information s1=new Information ();
		s1.setName("ABC");
		s1.setId(2000030001);
		s1.setGender('M');
		s1.setDepartment("CSE");
		Information s2=new Information();
		s2.setName("XYZ");
		s2.setId(2000030002);
		s2.setGender('M');
		s2.setDepartment("CSE");
		System.out.println("Student details are");
		System.out.println(s1);
		System.out.println(s2);
		
	
	}
}