package lab2qns2;

public class Information {
	private String name;
	private long id;
	private char gender;
	private String department;
	public void setName(String name)
	{
	this.name = name;
	}
	public void setId(long id)
	{
	this.id = id;
	}
	public void setGender(char gender)
	{
	this.gender = gender;
	}
	public void setDepartment(String department)
	{
	this.department = department;
	}
	public String toString()
	{
	String str;
	str="\nID: "+id+"\nName: "+name+"\nGender: "+gender+"\nDepartment: "+ department;
	return str;
	}
	

}
