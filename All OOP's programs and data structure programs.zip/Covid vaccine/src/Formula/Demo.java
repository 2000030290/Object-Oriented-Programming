package Formula;

import java.util.Scanner;
		public class Demo {
			 static Scanner sc=new Scanner(System.in);
			
			 static VaccineFormula q=new  VaccineFormula();
			 public static void main(String[] args) {
			    boolean repeat=true;
				int ch;
				while(repeat)
				{
					System.out.println("***MENU***");
					System.out.println("1.bharat biotech");
					System.out.println("2.serum institute");
					System.out.println("3.Exit");
					System.out.println("Enter your choice");
					ch=sc.nextInt();
					switch(ch)
					{
					case 1: q.Bharatformula();
					        break;
					case 2: q.serumformula();
					        break;
					case 3: repeat=false;
						    break;
					default: System.out.println("INVALID CHOICE");
					}
				}
				
			}

		}
