package Formula;

 public class VaccineFormula {
     private String Bharathformula="an-deg";
     private String serumformula="apz-rtxc";
	 public void Bharatformula()
	 {
		 System.out.println(" Bharatformula = "+Bharathformula);
	 }
	 public void  serumformula()
	 {
		 System.out.println(" serumformula = "+serumformula);
	 }
}