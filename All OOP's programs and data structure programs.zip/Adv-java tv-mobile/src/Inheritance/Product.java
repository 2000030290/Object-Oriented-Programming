package Inheritance;

	import java.util.*;
	 
	public class Product  {
	    int pid;
	    String name;
	    double price;

	        void product(int pid,String name,double price) {
	        this.pid=pid;
	        this.name=name;
	        this.price=price;    
	    }
	        public static void main(String[] args) {
	            //Scanner sc=new Scanner(System.in);
	            Ledtv l=new Ledtv();
	            Mobile m=new Mobile();
	            System.out.println("Televison details");
	            l.product(1234,"Smart TV",70000);
	            l.ledtv("Sony",44);
	            System.out.println("\nMobile details");
	            m.product(5678,"Mobile", 50000);
	            m.mobile(4,"Android",128);
	        }
	}
	class Ledtv extends Product{
	    String brand;
	    int size;
	    void ledtv(String brand,int size) {

	        this.brand=brand;
	        this.size=size;
	        System.out.println("product id :"+pid+"\nproduct name :"+name+"\nprice :"+price+"\nbrand :"+brand+"\nsize :"+size+"inches");
	    }
	}
	class Mobile extends Product{
	    int ram;
	    String os;
	    int memory;
	    void mobile(int ram,String os,int memory) {
	        this.ram=ram;
	        this.os=os;
	        this.memory=memory;
	        System.out.println("product id :"+pid+"\nproduct name :"+name+"\nprice :"+price+"\nRAM :"+ram+"\noperating system :"+os+"\ninternal memory :"+memory+"GB");
	    }
	}

