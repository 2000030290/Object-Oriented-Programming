package exception;

public class Rectangle extends GeometricShape{
   private double length,breadth;
   public Rectangle(double length,double breadth,String boardercolor,double boarderwidth) throws InvalidDimensionException
   {
	   super(boardercolor,boarderwidth);
	   setlength(length);
	   setbreadth(breadth);
	   
   }

private void setlength(double length) throws InvalidDimensionException
{
	if(length>=0)
	{
		this.length=length;
	}
	else
	{
		throw new InvalidDimensionException();
	}
	
}
private void setbreadth(double breadth) throws InvalidDimensionException
{
	
	if(breadth>=0)
	{
		this.breadth=breadth;
	}
	else
	{
		throw new InvalidDimensionException();
	}
}
	public String toString()
	{
		String s;
		s=super.toString();
	    s=s+"\n Length-"+length;
	    s=s+"\n Breadth-"+breadth;
	    return s;
	
	
}

}
