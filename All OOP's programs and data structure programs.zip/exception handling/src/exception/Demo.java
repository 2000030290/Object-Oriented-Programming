package exception;
import java.util.Scanner;
public class Demo {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	try
	{
		GeometricShape g=new Rectangle(sc.nextDouble(),sc.nextDouble(),sc.next(),sc.nextDouble());
		System.out.println(g);
	}
	catch(Exception e) {
	System.out.println(e);
	}
	}

}
