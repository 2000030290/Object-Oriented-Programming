package exception;

public class InvalidDimensionException extends Exception {
	
	public String toString()
	{
		
		return "Invalid value of dimension";
	}

}
