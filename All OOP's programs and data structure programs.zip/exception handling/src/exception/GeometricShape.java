package exception;

public class GeometricShape {
	private String boardercolor;
	private double boarderwidth;
	public GeometricShape(String boardercolor, double boarderwidth)
	{
		this.boardercolor=boardercolor;
		this.boarderwidth=boarderwidth;
	}
	public String toString()
	{
		String s;
		s="Boardercolor-"+boardercolor;
		s=s+"\n Boarderwidth-"+boarderwidth;
		return s;
	}

}
