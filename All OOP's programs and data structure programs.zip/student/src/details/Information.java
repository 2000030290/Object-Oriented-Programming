package details;
import java.util.Scanner;

public class Information {

	public static void main(String[] args) {
	
	
			  Scanner sc=new Scanner(System.in);
			  Aboutstudent ob=new Aboutstudent();
			  System.out.println("Enter Id:");
			  ob.id=sc.nextLong();
			  System.out.println("Enter Name:");
			  ob.name=sc.next();
			  System.out.println("Enter Gender:");
			  ob.gender=sc.next();
			  System.out.println("Enter Department:");
			  ob.dept=sc.next();
			  System.out.println(ob);
			 }

	}


