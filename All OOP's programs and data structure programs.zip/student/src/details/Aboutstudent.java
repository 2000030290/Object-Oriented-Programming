package details;

public class Aboutstudent {
	public long id;
	 public String name;
	 public String gender;
	 public String dept;
	 public void Attri(long id,String name,String gender,String dept) {
	  this.id=id;
	  this.name=name;
	  this.gender=gender;
	  this.dept=dept;
	 }
	 public long getid() {
	  return id;
	 }
	 public String getName()
	 {
	  return name;
	 }
	 public String getGender()
	 {
	  return gender;
	 }
	 public String getDept() {
	  return dept;
	 }
	 public String toString()
	 {
	  String S;
	  S="Id:"+id+"\n"+"name:"+name+"\n"+"gender:"+gender+"\n"+"Dept:"+dept+"\n";
	  return S;
	 }


}
