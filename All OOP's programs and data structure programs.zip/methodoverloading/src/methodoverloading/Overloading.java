package methodoverloading;

public class Overloading {

	public static void main(String[] args) {
		
    Sum o=new Sum();
    System.out.println(o.add(4,5,6));
    o.operation(8,"akhil");
	}

}
