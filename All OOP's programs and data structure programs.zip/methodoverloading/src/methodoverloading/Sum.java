package methodoverloading;

public class Sum {
	public int add(int a,int b) {
		return a+b;
	}
	public int add(int a,int b,int c)
	{
		return a+b+c;
	}
    public void operation(int age , String name)
    {
    	System.out.println("age is"+age+"name is "+name);
    }
    
}
