package array;
import java.util.Scanner;
public class Cuboid {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Cuboid c[]=new Cuboid[3];
		for(int i=0;i<=3;i++)
		{
			double len=sc.nextDouble();
			double bre=sc.nextDouble();
	        double hei=sc.nextDouble();
	        c[i]=new Demo(len,bre,hei);
	        System.out.println(c[i].volume());
		}

	}

}
