package array;

public class Demo {
	private double length,breadth,height;
	public Demo() {
		length=breadth=height=1;
	}
	public double volume()
	{
		return length*breadth*height;
	}
	
}
