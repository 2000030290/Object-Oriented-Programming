package AL;
import java.util.ArrayList;
import java.util.*;
public class DemoAL {

		public static void main(String[] args) {
		ArrayList<String> cars = new ArrayList<String>();
		cars.add("Volvo");
		cars.add("BMW");
		cars.add("Ford");
		cars.add("Mazda");
		System.out.println(cars);

		for (int i = 0; i < cars.size(); i++)
		{ 
			System.out.println(cars.get(i));
		}

		System.out.println("After sort");
		Collections.sort(cars);

		for (String i: cars) 
		{
			System.out.println(i);
		}

		System.out.println("After Clear");
		cars.clear();
		for (String i : cars)
		{
		System.out.println(i);
		}
		ArrayList<Integer> speed = new ArrayList<>();
		speed.add (100); 
		speed.add(120);
		speed.add(110);
		speed.add(125);
		System.out.println(speed);
		
	}
}
