package samplecal;

import static org.junit.Assert.*;

import org.junit.Test;

public class test1 {

	@Test
	public void testTestAdd() {
		fail("Not yet implemented");
	}

}
