package samplecal;
import static org.junit.Assert.*; 

import org.junit.Test;

public class cal {
	@Test 
	   public void testAdd() { 
    test t=new test();   
int a =10,b=10,actual=t.add(a, b),expected=20; 
assertEquals(actual, expected); 
} 


}
