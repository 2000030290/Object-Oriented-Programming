package samplecal;

public class test {
	  public int add(int a,int b) {
		    return a+b;
		  }

}
