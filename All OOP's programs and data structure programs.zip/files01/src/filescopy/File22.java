package filescopy;
import java.io.File;
import java.util.Scanner;
import java.io.PrintWriter;
public class File22 {

	public static void main(String[] args)throws Exception {
    File f1=new File("C:\\Users\\DELL\\eclipse-workspace\\files01\\src\\filescopy\\cse.txt");	
    File f2=new File("C:\\Users\\DELL\\eclipse-workspace\\files01\\src\\filescopy\\ece.txt");
    File f3=new File("C:\\Users\\DELL\\eclipse-workspace\\files01\\src\\filescopy\\student.txt");
    PrintWriter p=new PrintWriter(f3);
    Scanner s;
     s=new Scanner(f1);
     String n;
    while(s.hasNextLine());
    {
    	n=s.nextLine();
     p.write(n);
     p.println();
    }
    s=new Scanner(f2);
    while(s.hasNextLine());
    {
    	n=s.nextLine();
        p.write(n);
        p.println();
        System.out.println(n);
        System.out.println("\n");
    	}
    p.close();
    s.close();
    
	}
	

}