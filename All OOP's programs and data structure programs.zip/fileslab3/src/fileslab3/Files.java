package fileslab3;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;


public class Files {

	public static void main(String[] args)throws Exception {
		 File f1=new File("C:\\Users\\DELL\\eclipse-workspace\\fileslab3\\src\\fileslab3\\CSE.txt ");
		 File f2=new File("C:\\Users\\DELL\\eclipse-workspace\\fileslab3\\src\\fileslab3\\ECE.txt "); 
		 File f3=new File("C:\\Users\\DELL\\eclipse-workspace\\fileslab3\\src\\fileslab3\\STUDENT.txt ");
		 Scanner sc=new Scanner(f1);
		 PrintWriter p=new PrintWriter(f3);
		 while(sc.hasNextLine())
		 {
			 p.write(sc.nextLine());
			
			 p.println();
			
		 }
		 sc=new Scanner(f2);
		 while(sc.hasNextLine())
		 {
			 p.write(sc.nextLine());
			 p.println();
		 }
		 p.close();
		 sc.close();
		 
	}
	

}
