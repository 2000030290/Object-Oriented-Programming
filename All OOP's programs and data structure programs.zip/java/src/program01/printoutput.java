package program01;

public class printoutput {

	public static void main(String[] args) {
		int n=6;
		int result;
		result=factorial(n);
		System.out.println("factorial value of n " + result);
		n=5;
		result=factorial(n);
		System.out.println("factorial value of n " + result);

	}
	public static int factorial(int x) {
	int result=1;
	for(int i=1;i<=x;i++)
    result=result*i;
	{
		return result;
	}

}
}