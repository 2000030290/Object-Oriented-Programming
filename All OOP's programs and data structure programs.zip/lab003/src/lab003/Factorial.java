package lab003;

public class Factorial {

	public static void main(String[] args) {
		int a=Integer.parseInt(args[0]); //command line arguments
		System.out.println(Demo.factorial(a));
	}

}
