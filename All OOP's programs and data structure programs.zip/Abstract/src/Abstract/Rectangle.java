package Abstract;

public class Rectangle extends GeometricShape{
      private double len,bre;
      public Rectangle(String color,double len,double bre)
      {
    	  super(color);
    	  this.len=len;
    	  this.bre=bre;
      }
      public double area()
      {
    	  return len*bre;
    	  
      }
      public double perimeter()
      {
    	  return 2*(len+bre);
      }
      public String toSting()
      {
    	  String s;
    	  s=super.toString();
    	  s=s+"\n length="+len;
    	  s=s+"\n breadth="+bre;
    	  return s;
      }
}
