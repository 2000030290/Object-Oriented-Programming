package Abstract;

public class Square extends GeometricShape {
      private double side;
      public double area()
      {
    	  return side*side;
      }
      public double perimeter()
      {
    	  return 4*side;
      }
      public Square(String color,double side )
      {
    	  super(color);
    	  this.side=side;
      }
      public String toString()
      {
    	  String s;
    	  s=super.toString();
    	  s=s+"\n side="+side;
    	  return s;
      }
}
