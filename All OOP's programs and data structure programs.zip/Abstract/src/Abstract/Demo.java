package Abstract;

public class Demo {

	public static void main(String[] args) {
		
		GeometricShape g=new Rectangle("Red",5,10);
		System.out.println(g);
		System.out.println(g.area());
		System.out.println(g.perimeter());
		GeometricShape s=new Square("Blue",5);
		System.out.println(s);
		System.out.println(s.area());
		System.out.println(s.perimeter());

	}

}
