package Abstract;

public abstract class GeometricShape {
	public String color;
	public abstract double area();
	public abstract double perimeter();
	public GeometricShape(String color)
	{
		this.color=color;
	}
	public String toString()
	{
		String s="color"+color;
		return s;
	}

}
