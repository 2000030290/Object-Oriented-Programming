package lab5_002;
import java.util.Scanner;
public class Demo {

	public static void main(String[] args) {
		 String d[]=new String[10];
	      Scanner sc=new Scanner(System.in);
	      int i;
	      System.out.println("Enter your dates");
	      for(i=0;i<4;i++)
	      {
	        d[i]=sc.next();
	      }
	      for(i=0;i<4;i++)
	      {
	        Demo.checkDate(d[i]);
	      }
	  }
	    public static void checkDate(String d)
	    {
	      String s1,s2,s3;
	      s1=d.substring(0,2);
	      int day=Integer.parseInt(s1);
	      s2=d.substring(3,5);
	      int month=Integer.parseInt(s2);
	      s3=d.substring(6,8);
	      int year=Integer.parseInt(s3);
	      int noofdays=0;
	      if(month==1||month==3||month==5||month==7||month==8||month==10||month==12)
	        noofdays=31;
	      else if(month==4||month==6||month==9||month==11)
	        noofdays=30;
	      else if(month==2)
	      {
	        if(year%4==0)
	          noofdays=29;
	        else
	          noofdays=28;
	      }
	      if(day>noofdays)
	        System.out.println("Invalid Date");
	      else
	      {
	        if(month==1)
	        {
	          System.out.print(day+"January");
	        }
	        else if(month==2)
	        {
	          System.out.print(day+"February");
	        }
	        else if(month==3)
	        {
	          System.out.print(day+"March");
	        }
	        else if(month==4)
	        {
	            System.out.print(day+"April");
	        }
	        else if(month==5)
	        {
	          System.out.print(day+"May");
	        }else if(month==6)
	        {
	          System.out.print(day+"June");
	        }
	        else if(month==7)
	        {
	          System.out.print(day+"July");
	        }
	        else if(month==8)
	        {
	          System.out.print(day+"August");
	        }
	        else if(month==9)
	        {
	          System.out.print(day+"September");
	        }
	        else if(month==10)
	        {
	          System.out.print(day+"October");
	        }
	        else if(month==11)
	        {
	          System.out.print(day+"November");
	        }
	        else if(month==12)
	        {
	          System.out.print(day+"December");
	        }
	      }
	      if(year<=99)
	      {
	        System.out.print("19"+year);
	      }
	      else
	      {
	        System.out.print("20"+year);
	      }
	    

	}

}
